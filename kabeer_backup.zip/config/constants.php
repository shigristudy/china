<?php
/**
 * Created by PhpStorm.
 * User: addy
 * Date: 6/30/20
 * Time: 1:05 AM
 */

return [
    'Transcription_ext' => '.mp3,.mov,.mp4,.wav,.aif,.aiff,.flac,.aac,.mkv,.mka,.ogg',
    'Translation_ext' => '.doc,.dot,.docx,.docm,.dotx,.dotm,.rtf,.odt,.ott,.pdf,.txt,.xls,.xlt,.xlsx,.xlsm,.xltx,.xltm,.ods,.ots,.tsv,.ppt,.pps,.pot,.pptx,.pptm,.ppsx,.ppsm,.potx,.potm,.odp,.otp,.htm,.html,.xhtml,.dtd,.json,.yaml,.yml,.pdf,.bmp,.png,.gif,.jpeg,.jpg,.tiff,.xliff,.sdlxliff,.tmx,.ttx,.xlf,.mif,.idml,.icml,.dita,.properties,.resx,.xml,.sxml,.txml,.dita,.strings,.srt,.wix,.po,.g,.ts',
    'Voiceover_ext' => '.doc,.dot,.docx,.docm,.dotx,.dotm,.rtf,.odt,.ott,.pdf,.txt,.xls,.xlt,.xlsx,.xlsm,.xltx,.xltm,.ods,.ots,.tsv,.ppt,.pps,.pot,.pptx,.pptm,.ppsx,.ppsm,.potx,.potm,.odp,.otp,.htm,.html,.xhtml,.dtd,.json,.yaml,.yml,.pdf,.bmp,.png,.gif,.jpeg,.jpg,.tiff,.xliff,.sdlxliff,.tmx,.ttx,.xlf,.mif,.idml,.icml,.dita,.properties,.resx,.xml,.sxml,.txml,.dita,.strings,.srt,.wix,.po,.g,.ts,.mov,.mp4,.mkv,.mka,.ogg'
];