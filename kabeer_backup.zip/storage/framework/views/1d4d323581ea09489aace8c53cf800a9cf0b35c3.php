<!-- BG Blur Section Starts -->
<div class="bg-blur"></div>
<!-- BG Blur Section Ends -->
<!-- Mobile Navigation Menu Section Starts -->
<div class="fixed-navbar-menu-mob-tab">
    <ul class="menu-listing-mob-tab">
        <li class="active"><a href="index.html">Home</a></li>
        <li><a href="transcription.html">Transkription</a></li>
        <li><a href="translation.html">Übersetzung</a></li>
        <li><a href="speech-production.html">Sprachproduktion</a></li>
        <li>
            <a href="#">Kundenkonto <i class="fas fa-chevron-down"></i></a>
            <ul class="sub-menu-listing-mob-tab">
                <li><a href="login.html">LogIn</a></li>
                <li><a href="registration.html">Registrieren</a></li>
            </ul>
        </li>
        <li>
            <a href="#">DE <i class="fas fa-chevron-down"></i></a>
            <ul class="sub-menu-listing-mob-tab">
                <li><a href="#">EN</a></li>
            </ul>
        </li>
    </ul>
    <div class="search-in-mob-tab">
        <i class="fas fa-search"></i>
        <p>Search</p>
    </div>
</div>
<!-- Mobile Navigation Menu Section Ends -->
<!-- Mobile Logo and Hamburger Menu Section Starts -->
<div class="container-fluid bg-logo-hamburger-menu-mob-tab-home">
    <div class="row flex-align-center-desktop">
        <div class="col-xs-6">
            <div class="header-logo-mob-tab">
                <a href="index.html">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-responsive" alt="" />
                </a>
            </div>
        </div>
        <div class="col-xs-6">
            <div class="burger-menu text-right">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </div>
</div>
<!-- Mobile Logo and Hamburger Menu Section Ends -->
<!-- Search Section Starts -->
<div class="fixed-search-pop-up-home">
    <div class="search-pop-up-home">
        <div class="search-pop-up-heading-home text-center">
            <p>Start Typing and Press Enter To Search</p>
            <form>
                <div class="input-group">
                    <input type="text" class="form-control form-control-search-home" />
                    <div class="input-group-btn">
                        <button class="btn btn-search-home" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="search-pop-up-close-home">
        <img src="<?php echo e(asset('assets/images/close.png')); ?>" class="img-responsive" alt="" />
    </div>
</div>
<!-- Search Section Ends -->
<!-- Desktop Logo and Navigationbar Menu Section Starts -->
<div class="container-fluid bg-logo-navbar-desktop-home">
    <div class="row">
        <div class="container">
            <div class="row flex-align-center-desktop">
                <div class="col-sm-3 col-md-2 col-lg-3">
                    <div class="header-desktop-logo">
                        <a href="index.html">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-responsive" alt="" />
                        </a>
                    </div>
                </div>
                <div class="col-sm-9 col-md-10 col-lg-9">
                    <div class="navbar-menu-desktop">
                        <ul class="menu-listing text-right">
                            <li class="active"><a href="index.html">Home</a></li>
                            <li><a href="transcription.html">Transkription</a></li>
                            <li><a href="translation.html">Übersetzung</a></li>
                            <li><a href="speech-production.html">Sprachproduktion</a></li>
                            <li>
                                <a href="#">Kundenkonto <i class="fas fa-chevron-down"></i></a>
                                <ul class="sub-menu-listing">
                                    <li><a href="#">LogIn</a></li>
                                    <li><a href="#">Registrieren</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">DE <i class="fas fa-chevron-down"></i></a>
                                <ul class="sub-menu-listing">
                                    <li><a href="#">EN</a></li>
                                </ul>
                            </li>
                            <li><a href="#"><i class="fas fa-search header-search"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Desktop Logo and Navigationbar Menu Section Ends --><?php /**PATH /Volumes/Works/Work/Germany(Laravel)/current code/aivox(laravel)/resources/views/includes/header.blade.php ENDPATH**/ ?>