<?php $__env->startSection('content'); ?>
    <div class="content-header row align-items-center m-0">
        <nav aria-label="breadcrumb" class="col-sm-4 order-sm-last mb-3 mb-sm-0 p-0 ">
            <ol class="breadcrumb d-inline-flex font-weight-600 fs-13 bg-white mb-0 float-sm-right">
                <li class="breadcrumb-item"><a href="#"><i class="hvr-buzz-out fas fa-home"></i></a></li>
                <li class="breadcrumb-item active"> <?php echo e(__('words.admin.order.order_list')); ?></li>
            </ol>
        </nav>
        <div class="col-sm-8 header-title p-0">
            <div class="media">
                <div class="header-icon text-success mr-3"><i class="hvr-buzz-out fas fa-users"></i></div>
                <div class="media-body">
                    <h1 class="font-weight-bold"> <?php echo e(__('words.admin.order.order_list')); ?></h1>
                    <small> <?php echo e(__('words.admin.order.order_list')); ?></small>
                </div>
            </div>
        </div>
    </div>
    <div class="body-content">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-body card-fill">
                    <div class="clearfix">
                        <h5 class="font-weight-bold float-left">
                            <?php echo e(__('words.admin.order.order_list')); ?>

                        </h5>
                        <form action="" class="form-inline float-right" method="post">
                            <?php echo csrf_field(); ?>
                            <select type="search" class="form-control form-control-sm mr-2" name="order_status">
                                <option value="0" selected>All</option>
                                <?php $__currentLoopData = $data_order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if($item->id == $order_status): ?> selected <?php endif; ?>><?php echo e($item->status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-sm btn-primary float-right mt-2 mt-md-0" id="btn-add-user"><i class="fas fa-shopping-bag mr-1"></i><?php echo e(__('words.admin.user.search')); ?></button>
                        </form>
                    </div>
                    <div class="table-responsive mt-2">
                        <table class="table table-bordered table-hover">
                            <thead class="thead-colored thead-primary">
                            <tr class="bg-blue">
                                <th style="width:40px">#</th>
                                <th><?php echo e(__('words.admin.order.service_type')); ?></th>
                                <th><?php echo e(__('words.admin.order.surname')); ?></th>
                                <th><?php echo e(__('words.admin.order.company')); ?></th>
                                <th><?php echo e(__('words.admin.order.total_price')); ?></th>
                                <th><?php echo e(__('words.admin.order.status')); ?></th>
                                <th><?php echo e(__('words.admin.order.email')); ?></th>
                                <th><?php echo e(__('words.admin.order.order_created')); ?></th>
                                <th style="width:150px"><?php echo e(__('words.admin.order.action')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $data_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <tr>
                                    <td><?php echo e((($data_order->currentPage() - 1 ) * $data_order->perPage() ) + $loop->iteration); ?></td>
                                    <td class="service_type" data-value="<?php echo e($item->service->name); ?>"><?php echo e($item->service->name); ?></td>
                                    <td class="username"><?php echo e($item->user->username); ?></td>
                                    <td class="company"><?php echo e($item->user->company); ?></td>
                                    <td class="price"><?php echo e($item->price); ?></td>
                                    <td class="status" data-value="<?php echo e($item->order_status_id); ?>" style="color:<?php switch($item->order_status_id): case (1): ?> lightgrey <?php break; ?> <?php case (2): ?> darkblue  <?php break; ?> <?php case (3): ?> green <?php break; ?> <?php case (4): ?> red  <?php break; ?> <?php case (5): ?> pink <?php break; ?> <?php case (6): ?> orange <?php break; ?> <?php default: ?> red <?php endswitch; ?> ">
                                        <?php echo e($item->order_status->status); ?>

                                    </td>
                                    <td class="email"><?php echo e($item->user->email); ?></td>
                                    <td class="order_created"><?php echo e($item->created_at); ?></td>
                                    <td class="py-1">
                                        <a href="javascript:;" class="btn btn-sm btn-primary btn-icon mr-1 btn-update-order" data-id="<?php echo e($item->id); ?>" data-toggle="tooltip" title="<?php echo e(__('words.admin.user.edit')); ?>"><i class="fa fa-edit"></i></a>
                                        <a href="<?php echo e(route('superadmin.order.delete', $item->id)); ?>" class="btn btn-sm btn-danger btn-icon mr-1 btn-confirm" data-toggle="tooltip" title="<?php echo e(__('words.admin.user.delete')); ?>"><i class="fas fa-trash-alt"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="15" align="center">No Data</td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="clearfix mt-2">
                            <div class="float-left" style="margin: 0;">
                                <p><?php echo e(__('words.admin.order.total')); ?> <strong style="color: red"><?php echo e($data_order->total()); ?></strong> <?php echo e(__('words.admin.order.items')); ?></p>
                            </div>
                            <div class="float-right" style="margin: 0;">
                                <?php echo $data_order->appends([
                                    'order' => $data_order->currentPage(),
                                    'order_status' => $order_status,
                                ])->links(); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="UpdateOrderModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title"><?php echo e(__('words.admin.order.change_order_status')); ?></h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <form action="" id="update_order_form" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" class="id">
                    <div class="modal-body">
                        <div class="form-group">
                            <label class="control-label"><?php echo e(__('words.admin.order.status')); ?> <span class="text-danger">*</span></label>
                            <select class="form-control order_status" name="order_status">
                                <?php $__currentLoopData = $data_order_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <span class="invalid-feedback order_status_error">
                                <strong></strong>
                            </span>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-primary btn-submit"><i class="fas fa-check mr-1"></i><?php echo e(__('words.admin.user.update')); ?></button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fas fa-times mr-1"></i><?php echo e(__('words.admin.user.close')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(document).ready(function () {

            $(".btn-update-order").click(function(){
                let id = $(this).data("id");
                let status = $(this).parents('tr').find(".status").data('value');

                console.log("status_value", status)
                $("#update_order_form .id").val(id);
                $("#update_order_form .order_status").val(status);


                $("#UpdateOrderModal").modal();
            });

            $("#update_order_form .btn-submit").click(function(){
                $(".page-loader-wrapper").fadeIn();
                $.ajax({
                    url: "<?php echo e(route('superadmin.order.update')); ?>",
                    type: 'POST',
                    dataType: 'json',
                    data: $('#update_order_form').serialize(),
                    success : function(response) {
                        $(".page-loader-wrapper").fadeOut();
                        if(response.status.msg == 'success') {
                            swal({
                                    title: response.data,
                                    type: "success",
                                    confirmButtonColor: "#007BFF",
                                    confirmButtonText: "OK",
                                },
                                function(){
                                    window.location.reload();
                                });
                        }
                    },
                    error: function(response) {
                        $(".page-loader-wrapper").fadeOut();
                        swal("Something went wrong", '', 'error')
                        console.log(response)
                    }
                });
            });

            $("#pagesize").change(function(){
                $("#pagesize_form").submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/aivox.de/httpdocs/resources/views/superadmin/order/index.blade.php ENDPATH**/ ?>