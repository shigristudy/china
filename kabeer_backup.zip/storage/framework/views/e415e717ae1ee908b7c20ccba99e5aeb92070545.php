<?php $__env->startSection('title', 'LOGIN'); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-log-in-pg">
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <h1><?php echo e(__('words.web.sign_in.header_text')); ?></h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-3 sign_in">
                        <form action="<?php echo e(route('login')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="email"><?php echo e(__('words.web.sign_in.email')); ?>:</label>
                                <input type="email" class="form-control" id="email" name="email"/>
                            </div>
                            <div class="form-group">
                                <label for="pwd"><?php echo e(__('words.web.sign_in.pwd')); ?>:</label>
                                <input type="password" class="form-control" id="password" name="password">
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-danger login" value="<?php echo e(__('words.web.sign_in.login')); ?>">
                            </div>
                            <div class="form-group form-group-lp">
                                <label class="remember-data-label">
                                    <input type="checkbox" name="remember-data" class="remember-data">
                                    <span></span>
                                    <span><?php echo e(__('words.web.sign_in.remember')); ?></span>
                                </label>
                            </div>
                            <div class="form-group form-group-lp">
                                <p class="forgot-pwd-lp"><a href="<?php echo e(route('forgot_password')); ?>"><?php echo e(__('words.web.sign_in.forgot')); ?></a></p>
                            </div>
                        </form>
                    </div>
                    <div class="col-sm-3"></div>
                    <div class="col-sm-3 sign_in">
                        <div class="ct_account">
                            <h3><?php echo e(__('words.web.sign_in.ct_account')); ?></h3>
                        </div>
                        <div class="benefit">
                            <h4><?php echo e(__('words.web.sign_in.benefit')); ?>:</h4>
                        </div>
                        <div class="txt_list">
                            <h4><?php echo e(__('words.web.sign_in.checkout')); ?></h4>
                            <p><?php echo e(__('words.web.sign_in.payment')); ?></p>
                            <h4><?php echo e(__('words.web.sign_in.preference')); ?></h4>
                            <p><?php echo e(__('words.web.sign_in.format')); ?></p>
                            <h4><?php echo e(__('words.web.sign_in.informed')); ?></h4>
                            <p><?php echo e(__('words.web.sign_in.history')); ?></p>
                        </div>
                        <div class="form-group">
                            <a href="<?php echo e(route('register')); ?>" class="btn btn-success register">
                                <?php echo e(__('words.web.sign_in.register')); ?>

                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/login.js')); ?>"></script>
    <!-- Scroll Js -->
    <script src="<?php echo e(asset('assets/js/scroll.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/aivox.de/httpdocs/resources/views/web/pages/auth/login.blade.php ENDPATH**/ ?>