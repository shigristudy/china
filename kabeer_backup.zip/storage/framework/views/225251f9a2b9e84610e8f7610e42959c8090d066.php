<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon Icon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon" />
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon" />
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>" type="text/css" />
    <!-- Bootstrap-3 Minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" type="text/css" />
    <!-- Slick Slider CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.min.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick-theme.min.css')); ?>" type="text/css" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" type="text/css" />
    <!-- Media CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/media.css')); ?>" type="text/css" />
</head>
<body>

<?php $__env->startSection('sidebar'); ?>
    <!-- BG Blur Section Starts -->
    <div class="bg-blur"></div>
    <!-- BG Blur Section Ends -->
    <!-- Mobile Navigation Menu Section Starts -->
    <div class="fixed-navbar-menu-mob-tab">
        <ul class="menu-listing-mob-tab">
            <li class="active"><a href="index.html">Home</a></li>
            <li><a href="transcription.html">Transkription</a></li>
            <li><a href="translation.html">Übersetzung</a></li>
            <li><a href="speech-production.html">Sprachproduktion</a></li>
            <li>
                <a href="#">Kundenkonto <i class="fas fa-chevron-down"></i></a>
                <ul class="sub-menu-listing-mob-tab">
                    <li><a href="login.html">LogIn</a></li>
                    <li><a href="registration.html">Registrieren</a></li>
                </ul>
            </li>
            <li>
                <a href="#">DE <i class="fas fa-chevron-down"></i></a>
                <ul class="sub-menu-listing-mob-tab">
                    <li><a href="#">EN</a></li>
                </ul>
            </li>
        </ul>
        <div class="search-in-mob-tab">
            <i class="fas fa-search"></i>
            <p>Search</p>
        </div>
    </div>
    <!-- Mobile Navigation Menu Section Ends -->
    <!-- Mobile Logo and Hamburger Menu Section Starts -->
    <div class="container-fluid bg-logo-hamburger-menu-mob-tab-home">
        <div class="row flex-align-center-desktop">
            <div class="col-xs-6">
                <div class="header-logo-mob-tab">
                    <a href="index.html">
                        <img src="../../assets/images/logo.png" class="img-responsive" alt="" />
                    </a>
                </div>
            </div>
            <div class="col-xs-6">
                <div class="burger-menu text-right">
                    <i class="fa fa-bars"></i>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Logo and Hamburger Menu Section Ends -->
    <!-- Search Section Starts -->
    <div class="fixed-search-pop-up-home">
        <div class="search-pop-up-home">
            <div class="search-pop-up-heading-home text-center">
                <p>Start Typing and Press Enter To Search</p>
                <form>
                    <div class="input-group">
                        <input type="text" class="form-control form-control-search-home" />
                        <div class="input-group-btn">
                            <button class="btn btn-search-home" type="submit">
                                <i class="fa fa-search"></i>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="search-pop-up-close-home">
            <img src="../../assets/images/close.png" class="img-responsive" alt="" />
        </div>
    </div>
    <!-- Search Section Ends -->
    <!-- Desktop Logo and Navigationbar Menu Section Starts -->
    <div class="container-fluid bg-logo-navbar-desktop-home">
        <div class="row">
            <div class="container">
                <div class="row flex-align-center-desktop">
                    <div class="col-sm-3 col-md-2 col-lg-3">
                        <div class="header-desktop-logo">
                            <a href="index.html">
                                <img src="../../assets/images/logo.png" class="img-responsive" alt="" />
                            </a>
                        </div>
                    </div>
                    <div class="col-sm-9 col-md-10 col-lg-9">
                        <div class="navbar-menu-desktop">
                            <ul class="menu-listing text-right">
                                <li class="active"><a href="index.html">Home</a></li>
                                <li><a href="transcription.html">Transkription</a></li>
                                <li><a href="translation.html">Übersetzung</a></li>
                                <li><a href="speech-production.html">Sprachproduktion</a></li>
                                <li>
                                    <a href="#">Kundenkonto <i class="fas fa-chevron-down"></i></a>
                                    <ul class="sub-menu-listing">
                                        <li><a href="#">LogIn</a></li>
                                        <li><a href="#">Registrieren</a></li>
                                    </ul>
                                </li>
                                <li>
                                    <a href="#">DE <i class="fas fa-chevron-down"></i></a>
                                    <ul class="sub-menu-listing">
                                        <li><a href="#">EN</a></li>
                                    </ul>
                                </li>
                                <li><a href="#"><i class="fas fa-search header-search"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Desktop Logo and Navigationbar Menu Section Ends -->
<?php echo $__env->yieldSection(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php $__env->startSection('footer'); ?>
    <!-- Footer Section Starts -->
    <div class="container-fluid bg-footer-home">
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-4 col-lg-4">
                        <div class="footer-heading">
                            <h4>Über uns</h4>
                            <div class="footer-about-description">
                                <p>Ursprünglich als „pro-tone audio agentur“ gegründet, spezialisieren wir uns seit 2001 auf Audiolokalisierungen in über 70 Sprachen. Zu unseren Kunden zählen europäische und amerikanische Fortune Global 500 Unternehmen aus unterschiedlichen Branchen aber auch Agenturen, Medienhäuser und Buchverlage. Die neu entwickelte AIVOX Plattform erweitert unser Portfolio um die Services Transkription und Übersetzung. Dabei unterstützen wir unsere Mitarbeiter durch den gezielten Einsatz von künstlicher Intelligenz und neuronalen Netzen. Auftragsbezogene Prozesse wie Bestellung, Kalkulation oder Dateiverwaltung wurden weitestgehend automatisiert. Das Unternehmen ist zu 100% Eigentum des Managements.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-4 col-lg-4">
                        <div class="footer-heading">
                            <h4>Services</h4>
                            <ul class="footer-services-listing">
                                <li><a href="transcription.html">Transkription</a></li>
                                <li><a href="translation.html">Übersetzung</a></li>
                                <li><a href="speech-production.html">Sprachproduktion</a></li>
                            </ul>
                            <h4>Rechtliches</h4>
                            <ul class="footer-legal-listing">
                                <li><a href="#">Impressum</a></li>
                                <li><a href="#">Allgemeine Geschäftsbedingungen</a></li>
                                <li><a href="#">Datenschutzerklärung</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="visible-sm clearfix"></div>
                    <div class="col-sm-6 col-md-4 col-lg-4">
                        <div class="footer-heading">
                            <h4>Fragen stellen</h4>
                            <form>
                                <div class="form-group-footer">
                                    <input type="text" class="form-control form-control-footer" placeholder="Dein Name" />
                                </div>
                                <div class="form-group-footer">
                                    <input type="text" class="form-control form-control-footer" placeholder="Deine E-Mail" />
                                </div>
                                <div class="form-group-footer">
                                    <input type="text" class="form-control form-control-footer" placeholder="Deine Mitteilung" />
                                </div>
                                <div class="form-group-footer">
                                    <input type="submit" class="btn-send" value="Senden" />
                                </div>
                            </form>
                            <div class="footer-form-description">
                                <p>Wenn du Fragen zu einem Projekt oder individuelle Anforderungen hast, kontaktiere uns bitte. Wir helfen dir gerne weiter. Wenn du bereits eine Bestellnummer hast, gib diese bitte im Formulartext ein. Wir werden deine Fragen so schnell wie möglich beantworten.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Section Ends -->
    <!-- Copyright Section Starts -->
    <div class="container-fluid bg-copyright-home">
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="copyright-info text-center">
                            <p>We <i class="far fa-heart"></i> localization. Copyright 2020. AIVOX. All rights reserved.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Copyright Section Ends -->
    <!-- Scroll To Top Section Starts -->
    <div class="scroll-to-top-home">
        <a href="#home">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll To Top Section Ends -->
<?php echo $__env->yieldSection(); ?>
<!-- jQuery Library -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<!-- Slick Slide JS -->
<script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
<!-- Home Page JS -->
<script src="<?php echo e(asset('assets/js/home-page.js')); ?>"></script>
<!-- Accordion JS -->
<script src="<?php echo e(asset('assets/js/accordion.js')); ?>"></script>
<!-- Custom JS -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>
</html><?php /**PATH /Volumes/Works/Work/Germany(Laravel)/current code/aivox(laravel)/resources/views/layouts/default.blade.php ENDPATH**/ ?>