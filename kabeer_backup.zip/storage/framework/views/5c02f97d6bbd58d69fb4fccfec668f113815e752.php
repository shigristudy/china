<?php $__env->startSection('title', 'LOGIN'); ?>
<?php $__env->startSection('content'); ?>
    <!-- LogIn Form Section Starts -->
    <div class="container-fluid bg-log-in-pg">
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="welcome-icon-heading-lp">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 496 512"><path d="M248 8C111 8 0 119 0 256s111 248 248 248 248-111 248-248S385 8 248 8zm0 464c-119.1 0-216-96.9-216-216S128.9 40 248 40s216 96.9 216 216-96.9 216-216 216zm90.2-146.2C315.8 352.6 282.9 368 248 368s-67.8-15.4-90.2-42.2c-5.7-6.8-15.8-7.7-22.5-2-6.8 5.7-7.7 15.7-2 22.5C161.7 380.4 203.6 400 248 400s86.3-19.6 114.8-53.8c5.7-6.8 4.8-16.9-2-22.5-6.8-5.6-16.9-4.7-22.6 2.1zM168 240c17.7 0 32-14.3 32-32s-14.3-32-32-32-32 14.3-32 32 14.3 32 32 32zm160 0c17.7 0 32-14.3 32-32s-14.3-32-32-32-32 14.3-32 32 14.3 32 32 32z"></path></svg>
                            <h1>Welcome!</h1>
                        </div>
                    </div>
                </div>
                <form>
                    <div class="row">
                        <div class="col-sm-4 col-sm-offset-1 col-md-3 col-md-offset-1 col-lg-2 col-lg-offset-1">
                            <div class="form-group form-group-lp">
                                <label for="username">Username:</label>
                                <input type="text" class="form-control form-control-rl" id="username" />
                            </div>
                            <div class="form-group form-group-lp">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control form-control-rl" id="password" />
                            </div>
                            <div class="form-group form-group-lp">
                                <label class="remember-data-label">
                                    <input type="checkbox" name="remember-data" class="remember-data">
                                    <span></span>
                                    <span>Remember login</span>
                                </label>
                            </div>
                            <div class="form-group form-group-lp">
                                <p class="forgot-pwd-lp"><a href="#">Forgot your password?</a></p>
                            </div>
                        </div>
                        <div class="col-sm-3 col-sm-offset-4 col-md-3 col-md-offset-5 col-lg-2 col-lg-offset-7">
                            <input type="submit" class="btn-log-in" value="LOGIN" />
                        </div>
                    </div>
                </form>
                <div class="regis-bb-lp"></div>
                <div class="go-to-regis">
                    <p>You don't have a customer account yet?</p>
                    <a href="registration.html">Register</a>
                </div>
            </div>
        </div>
    </div>
    <!-- LogIn Form Section Ends -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/login.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Works/Work/Germany(Laravel)/aivox/aivox(laravel)/resources/views/pages/auth/login.blade.php ENDPATH**/ ?>