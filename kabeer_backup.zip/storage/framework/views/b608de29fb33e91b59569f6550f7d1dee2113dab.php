<!-- Footer Section Starts -->
<div class="container-fluid bg-footer-home">
    <div class="row">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4><?php echo e(__('words.web.footer.about_us')); ?></h4>
                        <div class="footer-about-description">
                            <p><?php echo e(__('words.web.footer.about_us_des')); ?></p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4><?php echo e(__('words.web.footer.service')); ?></h4>
                        <ul class="footer-services-listing">
                            <li><a href="<?php echo e(route('transcription')); ?>"><?php echo e(__('words.web.footer.transcription')); ?></a></li>
                            <li><a href="<?php echo e(route('translation')); ?>"><?php echo e(__('words.web.footer.translation')); ?></a></li>
                            <li><a href="<?php echo e(route('voiceover')); ?>" ><?php echo e(__('words.web.footer.voiceover')); ?></a></li>
                        </ul>
                        <h4><?php echo e(__('words.web.footer.legal')); ?></h4>
                        <ul class="footer-legal-listing">
                            <li><a href="#"><?php echo e(__('words.web.footer.imprint')); ?></a></li>
                            <li><a href="#"><?php echo e(__('words.web.footer.terms')); ?></a></li>
                            <li><a href="#"><?php echo e(__('words.web.footer.policy')); ?></a></li>
                        </ul>
                    </div>
                </div>
                <div class="visible-sm clearfix"></div>
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4><?php echo e(__('words.web.footer.contact_us')); ?></h4>
                        <form>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="<?php echo e(__('words.web.footer.yourname')); ?>" />
                            </div>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="<?php echo e(__('words.web.footer.youremail')); ?>" />
                            </div>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="<?php echo e(__('words.web.footer.yourmessage')); ?>" />
                            </div>
                            <div class="form-group-footer">
                                <input type="submit" class="btn-send" value="<?php echo e(__('words.web.footer.send')); ?>" />
                            </div>
                        </form>
                        <div class="footer-form-description">
                            <p><?php echo e(__('words.web.footer.question')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer Section Ends -->
<!-- Copyright Section Starts -->
<div class="container-fluid bg-copyright-home">
    <div class="row">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="copyright-info text-center">
                        <p>We <i class="far fa-heart"></i> localization. Copyright 2020. AIVOX. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Copyright Section Ends -->
<!-- Scroll To Top Section Starts -->
<div class="scroll-to-top-home">
    <a href="#home">
        <i class="fas fa-chevron-up"></i>
    </a>
</div>
<!-- Scroll To Top Section Ends --><?php /**PATH /Volumes/Work/php/laravel/aivox(laravel)/resources/views/web/includes/footer.blade.php ENDPATH**/ ?>