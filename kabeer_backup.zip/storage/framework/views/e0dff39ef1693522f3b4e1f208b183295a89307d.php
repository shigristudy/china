<!-- Footer Section Starts -->
<div class="container-fluid bg-footer-home">
    <div class="row">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4>Über uns</h4>
                        <div class="footer-about-description">
                            <p>Ursprünglich als „pro-tone audio agentur“ gegründet, spezialisieren wir uns seit 2001 auf Audiolokalisierungen in über 70 Sprachen. Zu unseren Kunden zählen europäische und amerikanische Fortune Global 500 Unternehmen aus unterschiedlichen Branchen aber auch Agenturen, Medienhäuser und Buchverlage. Die neu entwickelte AIVOX Plattform erweitert unser Portfolio um die Services Transkription und Übersetzung. Dabei unterstützen wir unsere Mitarbeiter durch den gezielten Einsatz von künstlicher Intelligenz und neuronalen Netzen. Auftragsbezogene Prozesse wie Bestellung, Kalkulation oder Dateiverwaltung wurden weitestgehend automatisiert. Das Unternehmen ist zu 100% Eigentum des Managements.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4>Services</h4>
                        <ul class="footer-services-listing">
                            <li><a href="transcription.html">Transkription</a></li>
                            <li><a href="translation.html">Übersetzung</a></li>
                            <li><a href="speech-production.html">Sprachproduktion</a></li>
                        </ul>
                        <h4>Rechtliches</h4>
                        <ul class="footer-legal-listing">
                            <li><a href="#">Impressum</a></li>
                            <li><a href="#">Allgemeine Geschäftsbedingungen</a></li>
                            <li><a href="#">Datenschutzerklärung</a></li>
                        </ul>
                    </div>
                </div>
                <div class="visible-sm clearfix"></div>
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4>Fragen stellen</h4>
                        <form>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="Dein Name" />
                            </div>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="Deine E-Mail" />
                            </div>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="Deine Mitteilung" />
                            </div>
                            <div class="form-group-footer">
                                <input type="submit" class="btn-send" value="Senden" />
                            </div>
                        </form>
                        <div class="footer-form-description">
                            <p>Wenn du Fragen zu einem Projekt oder individuelle Anforderungen hast, kontaktiere uns bitte. Wir helfen dir gerne weiter. Wenn du bereits eine Bestellnummer hast, gib diese bitte im Formulartext ein. Wir werden deine Fragen so schnell wie möglich beantworten.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer Section Ends -->
<!-- Copyright Section Starts -->
<div class="container-fluid bg-copyright-home">
    <div class="row">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="copyright-info text-center">
                        <p>We <i class="far fa-heart"></i> localization. Copyright 2020. AIVOX. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Copyright Section Ends -->
<!-- Scroll To Top Section Starts -->
<div class="scroll-to-top-home">
    <a href="#home">
        <i class="fas fa-chevron-up"></i>
    </a>
</div>
<!-- Scroll To Top Section Ends --><?php /**PATH /Volumes/Works/Work/Germany(Laravel)/current code/aivox(laravel)/resources/views/includes/footer.blade.php ENDPATH**/ ?>