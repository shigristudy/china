<?php
    $page = config('site.page');
?>
<nav class="sidebar sidebar-bunker">
    <div class="sidebar-header">
        <a href="<?php echo e(route('admin.home')); ?>" class="logo mx-auto"><span><?php echo e(config('app.name')); ?></span></a>
    </div>
    <hr class="my-0 bg-success">
    <div class="profile-element d-flex align-items-center flex-shrink-0">
        <div class="avatar online">
            <img src="<?php echo e(asset('assets/images/avatar128.png')); ?>" class="img-fluid rounded-circle" alt="">
        </div>
        <div class="profile-text">
            <h6 class="m-0">
                <?php if(Auth::guard('admin')->check()): ?>
                    <?php echo e(Auth::guard('admin')->user()->username); ?>

                <?php elseif(Auth::guard('superadmin')->check()): ?>
                    <?php echo e(Auth::guard('superadmin')->user()->username); ?>

                <?php endif; ?>

            </h6>
        </div>
    </div>
    <div class="sidebar-body">
        <nav class="sidebar-nav">
            <ul class="metismenu">
                <?php if(Auth::guard('admin')->check()): ?>
                    <li class="<?php if(request()->is('admin/dashboard')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('admin.home')); ?>"><i class="fas fa-tachometer-alt mr-2"></i> <?php echo e(__('words.admin.dashboard')); ?></a></li>
                    <li class="<?php if(request()->is('admin/user/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('admin.user.index')); ?>"><i class="fas fa-user-friends mr-2"></i> <?php echo e(__('words.admin.user.user_management')); ?></a></li>
                    <li class="<?php if(request()->is('admin/order/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('admin.order.index')); ?>"><i class="fas fa-shopping-bag mr-3"></i> <?php echo e(__('words.admin.order.orders')); ?></a></li>
                    <li class="<?php if(request()->is('admin/service_lang/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('admin.service_lang.index')); ?>"><i class="fas fa-angle-double-right mr-3"></i> <?php echo e(__('words.admin.service_lang.lang')); ?></a></li>
                    <li class="<?php if(request()->is('admin/price/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('admin.price.index')); ?>"><i class="fas fa-list mr-3"></i> <?php echo e(__('words.admin.price.prices')); ?></a></li>
                <?php elseif(Auth::guard('superadmin')->check()): ?>
                    <li class="<?php if(request()->is('superadmin/dashboard')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('superadmin.home')); ?>"><i class="fas fa-tachometer-alt mr-2"></i> <?php echo e(__('words.admin.dashboard')); ?></a></li>
                    <li>
                        <a class="has-arrow material-ripple" href="#">
                            <i class="fas fa-user-friends mr-2"></i> <?php echo e(__('words.admin.user.user_management')); ?>

                        </a>
                        <ul class="nav-second-level">
                            <li class="<?php if(request()->is('superadmin/user/admin/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('superadmin.user.admin_index')); ?>">Admin</a></li>
                            <li class="<?php if(request()->is('superadmin/user/customer/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('superadmin.user.customer_index')); ?>">Customer</a></li>
                            <li class="<?php if(request()->is('superadmin/user/role')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('superadmin.user.role_index')); ?>">Role</a></li>
                        </ul>
                    </li>
                    <li class="<?php if(request()->is('superadmin/order/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('superadmin.order.index')); ?>"><i class="fas fa-shopping-bag mr-2"></i><?php echo e(__('words.admin.order.orders')); ?></a></li>
                    <li class="<?php if(request()->is('superadmin/service_lang/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('superadmin.service_lang.index')); ?>"><i class="fas fa-angle-double-right mr-3"></i> <?php echo e(__('words.admin.service_lang.lang')); ?></a></li>
                    <li class="<?php if(request()->is('superadmin/price/*')): ?> mm-active <?php endif; ?>"><a href="<?php echo e(route('superadmin.price.index')); ?>"><i class="fas fa-list mr-3"></i> <?php echo e(__('words.admin.price.prices')); ?></a></li>
                <?php endif; ?>
                <li>
                    
                        
                        
                    
                    
                        
                        
                        
                    
                

                
                    
                        
                        
                    
                    
                        
                        
                        
                    

                
                
                
                
                
                
                    
                        
                        
                    
                    
                        
                        
                        
                        
                    
                
            </ul>
        </nav>
    </div>
</nav><?php /**PATH /var/www/vhosts/aivox.de/httpdocs/resources/views/layouts/aside.blade.php ENDPATH**/ ?>