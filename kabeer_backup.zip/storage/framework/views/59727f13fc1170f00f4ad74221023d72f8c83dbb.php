<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8"/>
    <meta name="description" content=""/>
    <meta name="author" content=""/>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0"/>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon Icon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon"/>
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon"/>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>" type="text/css"/>
    <!-- Bootstrap-3 Minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" type="text/css"/>
<?php echo $__env->yieldContent('style'); ?>
<!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" type="text/css"/>
    <!-- Media CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/media.css')); ?>" type="text/css"/>
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/toastr/toastr.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dropzone/dropzone.min.css')); ?>"/>

</head>
<body>
<?php echo $__env->make('web.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('web.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- jQuery Library -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/toastr/toastr.min.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
<!-- Custom JS -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('assets/dropzone/dropzone.min.js')); ?>"></script>
<script>
    var notification = '<?php echo session()->get("success");; ?>';
    if (notification != '') {
        toastr_call("success", "Success", notification);
    }
    var errors_string = '<?php echo json_encode($errors->all());; ?>';
    errors_string = errors_string.replace("[", "").replace("]", "").replace(/\"/g, "");
    var errors = errors_string.split(",");
    if (errors_string != "") {
        for (let i = 0; i < errors.length; i++) {
            const element = errors[i];
            toastr_call("error", "Error", element);
        }
    }

    function toastr_call(type, title, msg, override) {
        toastr[type](msg, title, override);
        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": false,
            "progressBar": true,
            "positionClass": "toast-top-center",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000",
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        }
    }

    // $(".btn-confirm").click(function(e){
    //     e.preventDefault();
    //     let url = $(this).attr('href');
    //     swal({
    //         title: "Are you sure?",
    //         type: 'warning',
    //         showCancelButton: true,
    //         confirmButtonColor: '#3085d6',
    //         cancelButtonColor: '#d33',
    //         confirmButtonText: "Yes",
    //         cancelButtonText: "Cancel",
    //     },function() {
    //         location.href = url
    //     })
    // })
</script>
<?php
    $exts = config('constants.Translation_ext');
    $route = route('trans_file_upload');
    if(session('current_service_type') == 1) {
        $exts = config('constants.Transcription_ext');
        $route = route('audio_file_upload');
    }

    if(session('current_service_type') == 2){
        $exts = config('constants.Translation_ext');
        $route = route('trans_file_upload');
    }
    if(session('current_service_type') == 3){
        $exts = config('constants.Voiceover_ext');
        $route = route('voiceover_file_upload');
    }
?>

<script>
    Dropzone.autoDiscover = false;

    var myDropzone = new Dropzone("a.js-dropzone", {
        url: "<?=$route?>",
        headers: {
            'x-csrf-token': '<?php echo e(csrf_token()); ?>',
        },
        acceptedFiles: "<?=$exts?>",
        paramName: "file",
        uploadMultiple: true,
        addRemoveLinks: true,
        sending: function (file, xhr, formData) {
            formData.append("service_id", <?php echo session('current_service_type')?>);
        },
        success: function (file, response) {
            file.previewElement.innerHTML = "";
            if (response.message === 'Unauthenticated') {
                location.href = "<?php echo e(route('login')); ?>";
            }
                toastr_call('success', 'Success', response.data.message);
            setTimeout(window.location.href = "/order/" + response.data.data.id, 1000);
        },
        error: function (file, res) {
            toastr_call("error", "Error", "Should be logged in!");
        }
    });
    myDropzone.on("removedfile", function (file) {
        var name = file.name;
        $.ajax({
            type: 'POST',
            url: '/file_delete.php',
            data: "fname=" + name,
            dataType: 'html'
        });
    });
</script>
</body>
</html><?php /**PATH /Volumes/Work/php/laravel/aivox(laravel)/resources/views/web/layouts/default.blade.php ENDPATH**/ ?>