<?php $__env->startSection('title', 'LOGIN'); ?>
<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-log-in-pg">
        <div class="row">
            <div class="container">
                <div class="row mb-5">
                    <div class="col-xs-12">
                        <h1><?php echo e(__('words.web.forgot_pwd.header_text')); ?></h1>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12 forgot_texts">
                        <?php echo e(__('words.web.forgot_pwd.text_1')); ?><br>
                        <?php echo e(__('words.web.forgot_pwd.text_2')); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-5 forgot_pwd">
                        <form action="<?php echo e(route('post_email')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-5">
                                <label for="email"><?php echo e(__('words.web.forgot_pwd.email')); ?>:</label>
                                <input type="email" class="form-control" id="email" name="email"/>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-danger forgot_btn" value="<?php echo e(__('words.web.forgot_pwd.submit')); ?>">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/login.js')); ?>"></script>
    <!-- Scroll Js -->
    <script src="<?php echo e(asset('assets/js/scroll.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/aivox.de/httpdocs/resources/views/web/pages/auth/forgot_password.blade.php ENDPATH**/ ?>