<?php $__env->startSection('style'); ?>
    <link href="<?php echo e(asset('assets')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-header row align-items-center m-0">
        <nav aria-label="breadcrumb" class="col-sm-4 order-sm-last mb-3 mb-sm-0 p-0 ">
            <ol class="breadcrumb d-inline-flex font-weight-600 fs-13 bg-white mb-0 float-sm-right">
                <li class="breadcrumb-item"><a href="#"><i class="hvr-buzz-out fas fa-home"></i></a></li>
                <li class="breadcrumb-item active"> <?php echo e(__('words.admin.service_lang.lang')); ?></li>
            </ol>
        </nav>
        <div class="col-sm-8 header-title p-0">
            <div class="media">
                <div class="header-icon text-success mr-3"><i class="hvr-buzz-out fas fa-users"></i></div>
                <div class="media-body">
                    <h1 class="font-weight-bold"> <?php echo e(__('words.admin.service_lang.lang')); ?></h1>

                    <small> <?php echo e(__('words.admin.service_lang.lang')); ?></small>
                </div>
            </div>
        </div>
    </div>
    <div class="body-content">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-body card-fill">
                    <div class="clearfix">
                        <h5 class="font-weight-bold float-left">
                            <?php echo e(__('words.admin.service_lang.lang')); ?>

                        </h5>
                    </div>
                    <div class="table-responsive mt-2">
                        <table class="table table-bordered table-hover">
                            <thead class="thead-colored thead-primary">
                                <tr class="bg-blue">
                                    <th style="width:40px">#</th>
                                    <th style="font-weight: 600"><?php echo e(__('words.admin.price.lang')); ?></th>
                                    <th style="width: 10px"><?php echo e(__('words.admin.service_lang.status')); ?></th>
                                    <th style="width: 10px"><?php echo e(__('words.admin.service_lang.actions')); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php $number = 1 ?>
                            <?php $__currentLoopData = $data_service_lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="number">&laquo; <?php echo e($number); ?> &raquo;</td>
                                    <td class="lang">&laquo; <?php echo e($item->lang); ?> &raquo;</td>
                                    <td>
                                        <?php if($item->status === 1): ?>
                                            <img src="<?php echo e(asset('backend/dist/img/status_active.png')); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('backend/dist/img/status_deactive.png')); ?>">
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('superadmin.service_lang.edit', $item->id)); ?>">
                                            <img src="<?php echo e(asset('backend/dist/img/edit.png')); ?>">
                                        </a>
                                    </td>

                                </tr>
                                <?php $number++?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/aivox.de/httpdocs/resources/views/superadmin/service/index.blade.php ENDPATH**/ ?>