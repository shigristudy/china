<!-- Preloader Section Starts -->
<div class="loader-wrapper">
    <div class="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- Preloader Section Ends -->
<!-- BG Blur Section Starts -->
<div class="bg-blur"></div>
<!-- BG Blur Section Ends -->
<!-- Mobile Navigation Menu Section Starts -->
<div class="fixed-navbar-menu-mob-tab">
    <ul class="menu-listing-mob-tab">
        <li class="<?php echo e((request()->is('/')) ? 'active' : ''); ?>"><a href="/"><?php echo e(__('words.web.header.home')); ?></a></li>
        <li class="<?php echo e((request()->is('transcription')) ? 'active' : ''); ?>"><a href="<?php echo e(route('transcription')); ?>"><?php echo e(__('words.web.header.transcription')); ?></a></li>
        <li class="<?php echo e((request()->is('translation')) ? 'active' : ''); ?>"><a href="<?php echo e(route('translation')); ?>"><?php echo e(__('words.web.header.translation')); ?></a></li>
        <li class="<?php echo e((request()->is('voiceover')) ? 'active' : ''); ?>"><a href="<?php echo e(route('voiceover')); ?>"><?php echo e(__('words.web.header.voiceover')); ?></a></li>
        <?php if(!Auth::check()): ?>
            <li class="<?php echo e((request()->is('login')) || (request()->is('register')) ? 'active' : ''); ?>">
                <a href="#">Account <i class="fas fa-chevron-down"></i></a>
                <ul class="sub-menu-listing-mob-tab">
                    <li><a href="<?php echo e(route('login')); ?>"><?php echo e(__('words.web.header.login')); ?></a></li>
                    <li><a href="<?php echo e(route('register')); ?>"><?php echo e(__('words.web.header.register')); ?></a></li>
                </ul>
            </li>
        <?php else: ?>
            <li class="<?php echo e((request()->is('profile')) || (request()->is('logout')) ? 'active' : ''); ?>">
                <a href="#">Account <i class="fas fa-chevron-down"></i></a>
                <ul class="sub-menu-listing-mob-tab">
                    <li><a href="<?php echo e(route('profile')); ?>"><?php echo e(__('words.web.header.profile')); ?></a></li>
                    <li><a href="<?php echo e(route('logout')); ?>"><?php echo e(__('words.web.header.logout')); ?></a></li>
                </ul>
            </li>
        <?php endif; ?>
        <li>
            <a href="#">DE <i class="fas fa-chevron-down"></i></a>
            <ul class="sub-menu-listing-mob-tab">
                <li><a href="#">EN</a></li>
            </ul>
        </li>
    </ul>
    <div class="search-in-mob-tab">
        <i class="fas fa-search"></i>
        <p>Search</p>
    </div>
</div>
<!-- Mobile Navigation Menu Section Ends -->
<!-- Mobile Logo and Hamburger Menu Section Starts -->
<div class="container-fluid bg-logo-hamburger-menu-mob-tab-home">
    <div class="row flex-align-center-desktop">
        <div class="col-xs-6">
            <div class="header-logo-mob-tab">
                <a href="">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-responsive" alt="" />
                </a>
            </div>
        </div>
        <div class="col-xs-6">
            <div class="burger-menu text-right">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </div>
</div>
<!-- Mobile Logo and Hamburger Menu Section Ends -->
<!-- Search Section Starts -->
<div class="fixed-search-pop-up-home">
    <div class="search-pop-up-home">
        <div class="search-pop-up-heading-home text-center">
            <p>Start Typing and Press Enter To Search</p>
            <form>
                <div class="input-group">
                    <input type="text" class="form-control form-control-search-home" />
                    <div class="input-group-btn">
                        <button class="btn btn-search-home" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="search-pop-up-close-home">
        <img src="<?php echo e(asset('assets/images/close.png')); ?>" class="img-responsive" alt="" />
    </div>
</div>
<!-- Search Section Ends -->
<!-- Desktop Logo and Navigationbar Menu Section Starts -->
<div class="container-fluid bg-logo-navbar-desktop-home <?php echo e((request()->is('profile')) || (request()->is('project')) || (request()->is('order/*')) ? 'active' : ''); ?>">
    <div class="row">
        <div class="container">
            <div class="row flex-align-center-desktop">
                <div class="col-sm-3 col-md-2 col-lg-3">
                    <div class="header-desktop-logo">
                        <a href="">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-responsive" alt="" />
                        </a>
                    </div>
                </div>
                <div class="col-sm-9 col-md-10 col-lg-9">
                    <div class="navbar-menu-desktop">
                        <ul class="menu-listing text-right">
                            <li class="<?php echo e((request()->is('/')) ? 'active' : ''); ?>"><a href="/"><?php echo e(__('words.web.header.home')); ?></a></li>
                            <li class="<?php echo e((request()->is('transcription')) ? 'active' : ''); ?>"><a href="<?php echo e(route('transcription')); ?>"><?php echo e(__('words.web.header.transcription')); ?></a></li>
                            <li class="<?php echo e((request()->is('translation')) ? 'active' : ''); ?>"><a href="<?php echo e(route('translation')); ?>"><?php echo e(__('words.web.header.translation')); ?></a></li>
                            <li class="<?php echo e((request()->is('voiceover')) ? 'active' : ''); ?>"><a href="<?php echo e(route('voiceover')); ?>"><?php echo e(__('words.web.header.voiceover')); ?></a></li>
                            <?php if(!Auth::check()): ?>
                                <li class="<?php echo e((request()->is('login')) || (request()->is('register')) ? 'active' : ''); ?>">
                                    <a href="#"><?php echo e(__('words.web.header.account')); ?> <i class="fas fa-chevron-down"></i></a>
                                    <ul class="sub-menu-listing">
                                        <li><a href="<?php echo e(route('login')); ?>"><?php echo e(__('words.web.header.login')); ?></a></li>
                                        <li><a href="<?php echo e(route('register')); ?>"><?php echo e(__('words.web.header.register')); ?></a></li>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li class="<?php echo e((request()->is('profile')) || (request()->is('logout')) || (request()->is('project'))? 'active' : ''); ?>">
                                    <a href="#">Account <i class="fas fa-chevron-down"></i></a>
                                    <ul class="sub-menu-listing">
                                        <li><a href="<?php echo e(route('profile')); ?>"><?php echo e(__('words.web.header.profile')); ?></a></li>
                                        <li><a href="<?php echo e(route('project')); ?>"><?php echo e(__('words.web.header.project')); ?></a></li>
                                        <li><a href="<?php echo e(route('logout')); ?>"><?php echo e(__('words.web.header.logout')); ?></a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>

                            <li>
                                <a href="#">
                                <?php $locale = session()->get('locale'); ?>
                                    <?php switch($locale):
                                        case ('en'): ?>
                                        <span> EN</span>
                                        <?php break; ?>
                                        <?php case ('de'): ?>
                                        <span> DE</span>
                                        <?php break; ?>
                                        <?php default: ?>
                                        <span> EN</span>
                                    <?php endswitch; ?>
                                <i class="fas fa-chevron-down"></i>
                                </a>
                                <ul class="sub-menu-listing">
                                    <?php switch($locale):
                                        case ('en'): ?>
                                        <li><a href="<?php echo e(route('lang', 'de')); ?>">DE</a></li>
                                        <?php break; ?>
                                        <?php case ('de'): ?>
                                        <li><a href="<?php echo e(route('lang', 'en')); ?>">EN</a></li>
                                        <?php break; ?>
                                        <?php default: ?>
                                        <li><a href="<?php echo e(route('lang', 'de')); ?>">DE</a></li>
                                    <?php endswitch; ?>
                                </ul>
                            </li>
                            <li><a href="#"><i class="fas fa-search header-search"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Desktop Logo and Navigationbar Menu Section Ends --><?php /**PATH /Volumes/Work/php/laravel/aivox(laravel)/resources/views/web/includes/header.blade.php ENDPATH**/ ?>