<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Banner Section Starts -->
    <div class="container-fluid bg-banner-home" id="home">
        <div class="bg-banner-bottom-shape-home">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                <path class="elementor-shape-fill" opacity="0.33" d="M473,67.3c-203.9,88.3-263.1-34-320.3,0C66,119.1,0,59.7,0,59.7V0h1000v59.7 c0,0-62.1,26.1-94.9,29.3c-32.8,3.3-62.8-12.3-75.8-22.1C806,49.6,745.3,8.7,694.9,4.7S492.4,59,473,67.3z"></path>
                <path class="elementor-shape-fill" opacity="0.66" d="M734,67.3c-45.5,0-77.2-23.2-129.1-39.1c-28.6-8.7-150.3-10.1-254,39.1 s-91.7-34.4-149.2,0C115.7,118.3,0,39.8,0,39.8V0h1000v36.5c0,0-28.2-18.5-92.1-18.5C810.2,18.1,775.7,67.3,734,67.3z"></path>
                <path class="elementor-shape-fill" d="M766.1,28.9c-200-57.5-266,65.5-395.1,19.5C242,1.8,242,5.4,184.8,20.6C128,35.8,132.3,44.9,89.9,52.5C28.6,63.7,0,0,0,0 h1000c0,0-9.9,40.9-83.6,48.1S829.6,47,766.1,28.9z"></path>
            </svg>
        </div>
        <div class="row">
            <div class="banner-info-home">
                <h1>Die Welt steht dir offen</h1>
                <p>Mach mehr aus deinem Content und erstelle internationale Sprachversionen. Wir helfen dir bei der Umsetzung.</p>
            </div>
        </div>
    </div>
    <!-- Banner Section Ends -->
    <!-- Transcription, Translation and Speech Production Box Section Starts -->
    <div class="container-fluid bg-ttsp-box-home">
        <div class="row">
            <div class="col-sm-4 col-md-4 col-lg-4">
                <div class="panel-ttsp-home panel-ttsp-home-one">
                    <a href="transcription.html">
                        <img src="../assets/images/home-1.jpg" class="img-responsive" alt="" />
                    </a>
                    <div class="panel-body-ttsp-home panel-body-ttsp-one-home">
                        <a href="transcription.html">
                            <h3>Transkription</h3>
                            <p>Wir verschriftlichen deinen Audio - und Video Content</p>
                        </a>
                    </div>
                    <div class="panel-ttsp-right-box-home">
                        <h3>ab 0,99€</h3>
                        <p>/min</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-md-4 col-lg-4">
                <div class="panel-ttsp-home panel-ttsp-home-two">
                    <a href="translation.html.html">
                        <img src="../assets/images/home-2.jpg" class="img-responsive" alt="" />
                    </a>
                    <div class="panel-body-ttsp-home panel-body-ttsp-two-home">
                        <a href="translation.html.html">
                            <h3>Übersetzung</h3>
                            <p>Wir übersetzen deine Dokumente in 76 Sprachen</p>
                        </a>
                    </div>
                    <div class="panel-ttsp-right-box-home">
                        <h3>ab 0,036€</h3>
                        <p>/Wort</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-md-4 col-lg-4">
                <div class="panel-ttsp-home panel-ttsp-home-three">
                    <a href="speech-production.html">
                        <img src="../assets/images/home-3.jpg" class="img-responsive" alt="" />
                    </a>
                    <div class="panel-body-ttsp-home panel-body-ttsp-three-home">
                        <a href="speech-production.html">
                            <h3>Sprachproduktion</h3>
                            <p>Buche professionelle Sprecher in über 70 Sprachen</p>
                        </a>
                    </div>
                    <div class="panel-ttsp-right-box-home">
                        <h3>ab 26€</h3>
                        <p>/min</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Transcription, Translation and Speech Production Box Section Ends -->
    <!-- Client Logo Section Starts -->
    <div class="container-fluid bg-client-logo-home">
        <div class="row">
            <div class="col-xs-12">
                <div class="client-logo-slick-slider-home">
                    <div><img src="../assets/images/client-1.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-2.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-3.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-4.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-5.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-6.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-7.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-8.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-9.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                    <div><img src="../assets/images/client-10.jpg" class="img-responsive img-client-logo-home" alt="" /></div>
                </div>
            </div>
        </div>
    </div>
    <!-- Client Logo Section Ends -->
    <!-- Transcription, Translation and Speak Icon-Heading-Desc Section Starts -->
    <div class="container-fluid bg-tts-icon-heading-desc-home">
        <div class="bg-tts-icon-heading-desc-overlay-home"></div>
        <div class="bg-tts-top-shape-home">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                <path class="elementor-shape-fill" d="M421.9,6.5c22.6-2.5,51.5,0.4,75.5,5.3c23.6,4.9,70.9,23.5,100.5,35.7c75.8,32.2,133.7,44.5,192.6,49.7
        c23.6,2.1,48.7,3.5,103.4-2.5c54.7-6,106.2-25.6,106.2-25.6V0H0v30.3c0,0,72,32.6,158.4,30.5c39.2-0.7,92.8-6.7,134-22.4
        c21.2-8.1,52.2-18.2,79.7-24.2C399.3,7.9,411.6,7.5,421.9,6.5z"></path>
            </svg>
        </div>
        <div class="bg-tts-bottom-shape-home">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                <path class="elementor-shape-fill" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3
				c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3
				c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path>
            </svg>
        </div>
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <div class="panel-tts-ihd-home panel-tts-ihd-home-one">
                            <img src="../assets/images/headset.png" class="img-responsive" alt="" />
                            <h3>1. Transkribieren</h3>
                            <p>Falls du kein Skript vorliegen hast, transkribieren wir zunächst die original Audio- oder Videodatei. Wir verschriftlichen alles Hörbare, fügen auf Wunsch Zeitstempel und Sprecherwechsel ein und glätten den Text so, dass du ihn anschliessend in weitere Sprachen übersetzen lassen kannst.</p>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <div class="panel-tts-ihd-home panel-tts-ihd-home-two">
                            <img src="../assets/images/language.png" class="img-responsive" alt="" />
                            <h3>2. Übersetzen</h3>
                            <p>Das Transkript kann nun in über 70 Sprachen übersetzt werden. Für jeden Text haben wir die passenden muttersprachlichen Fachübersetzer. Selbstverständlich achten wir dabei auch auf Länderbesonderheiten. Bereits übersetzte Worte zahlst du nicht doppelt.</p>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4">
                        <div class="panel-tts-ihd-home panel-tts-ihd-home-three">
                            <img src="../assets/images/mic.png" class="img-responsive" alt="" />
                            <h3>3. Sprechen lassen</h3>
                            <p>Sobald das perfekt lokalisierte Skript vorliegt, kannst du aus über 2.500 professionellen Sprechern in 76 Sprachen wählen. Die Aufnahmen erfolgen selbstverständlich in bester Studioqualität. Gerne übernehmen wir auf Wunsch auch die Postproduktion.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Transcription, Translation and Speak Icon-Heading-Desc Section Ends -->
    <!-- Testimonials Section Starts -->
    <div class="container-fluid bg-testimonials-home">
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="testimonials-heading text-center">
                            <h2>Was unsere Stimmen über uns sagen</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="testimonials-slick-slider-home">
                            <div>
                                <div class="testimonial-review">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum dignissimos, hic temporibus aspernatur eveniet ex beatae consequuntur officia. Quo omnis voluptatibus pariatur asperiores labore corporis ratione ad eligendi necessitatibus veniam.</p>
                                </div>
                                <div class="row">
                                    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-4 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                                        <div class="media media-testimonial">
                                            <div class="media-left media-left-testimonial">
                                                <img src="../assets/images/testimonial-1.jpg" class="media-object" alt="" />
                                            </div>
                                            <div class="media-body media-body-testimonial">
                                                <h4 class="media-heading">Mauricio</h4>
                                                <p>Lorem Ipsum</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="testimonial-review">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum dignissimos, hic temporibus aspernatur eveniet ex beatae consequuntur officia. Quo omnis voluptatibus pariatur asperiores labore corporis ratione ad eligendi necessitatibus veniam.</p>
                                </div>
                                <div class="row">
                                    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-4 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                                        <div class="media media-testimonial">
                                            <div class="media-left media-left-testimonial">
                                                <img src="../assets/images/testimonial-2.jpg" class="media-object" alt="" />
                                            </div>
                                            <div class="media-body media-body-testimonial">
                                                <h4 class="media-heading">Mauricio</h4>
                                                <p>Lorem Ipsum</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="testimonial-review">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum dignissimos, hic temporibus aspernatur eveniet ex beatae consequuntur officia. Quo omnis voluptatibus pariatur asperiores labore corporis ratione ad eligendi necessitatibus veniam.</p>
                                </div>
                                <div class="row">
                                    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-4 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                                        <div class="media media-testimonial">
                                            <div class="media-left media-left-testimonial">
                                                <img src="../assets/images/testimonial-3.jpg" class="media-object" alt="" />
                                            </div>
                                            <div class="media-body media-body-testimonial">
                                                <h4 class="media-heading">Mauricio</h4>
                                                <p>Lorem Ipsum</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="testimonial-review">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum dignissimos, hic temporibus aspernatur eveniet ex beatae consequuntur officia. Quo omnis voluptatibus pariatur asperiores labore corporis ratione ad eligendi necessitatibus veniam.</p>
                                </div>
                                <div class="row">
                                    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-4 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                                        <div class="media media-testimonial">
                                            <div class="media-left media-left-testimonial">
                                                <img src="../assets/images/testimonial-4.jpg" class="media-object" alt="" />
                                            </div>
                                            <div class="media-body media-body-testimonial">
                                                <h4 class="media-heading">Mauricio</h4>
                                                <p>Lorem Ipsum</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="testimonial-review">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum dignissimos, hic temporibus aspernatur eveniet ex beatae consequuntur officia. Quo omnis voluptatibus pariatur asperiores labore corporis ratione ad eligendi necessitatibus veniam.</p>
                                </div>
                                <div class="row">
                                    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-4 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                                        <div class="media media-testimonial">
                                            <div class="media-left media-left-testimonial">
                                                <img src="../assets/images/testimonial-5.jpg" class="media-object" alt="" />
                                            </div>
                                            <div class="media-body media-body-testimonial">
                                                <h4 class="media-heading">Mauricio</h4>
                                                <p>Lorem Ipsum</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="testimonial-review">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum dignissimos, hic temporibus aspernatur eveniet ex beatae consequuntur officia. Quo omnis voluptatibus pariatur asperiores labore corporis ratione ad eligendi necessitatibus veniam.</p>
                                </div>
                                <div class="row">
                                    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-4 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                                        <div class="media media-testimonial">
                                            <div class="media-left media-left-testimonial">
                                                <img src="../assets/images/testimonial-6.jpg" class="media-object" alt="" />
                                            </div>
                                            <div class="media-body media-body-testimonial">
                                                <h4 class="media-heading">Mauricio</h4>
                                                <p>Lorem Ipsum</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="testimonial-review">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cum dignissimos, hic temporibus aspernatur eveniet ex beatae consequuntur officia. Quo omnis voluptatibus pariatur asperiores labore corporis ratione ad eligendi necessitatibus veniam.</p>
                                </div>
                                <div class="row">
                                    <div class="col-xs-10 col-xs-offset-1 col-sm-4 col-sm-offset-4 col-md-4 col-md-offset-4 col-lg-4 col-lg-offset-4">
                                        <div class="media media-testimonial">
                                            <div class="media-left media-left-testimonial">
                                                <img src="../assets/images/testimonial-7.jpg" class="media-object" alt="" />
                                            </div>
                                            <div class="media-body media-body-testimonial">
                                                <h4 class="media-heading">Mauricio</h4>
                                                <p>Lorem Ipsum</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Testimonials Section Ends -->
    <!-- Company Information Section Starts -->
    <div class="container-fluid bg-company-info-home">
        <div class="company-info-top-shape-home">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                <path class="elementor-shape-fill" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3
				c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3
				c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path>
            </svg>
        </div>
        <div class="company-info-bottom-shape-home">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 100" preserveAspectRatio="none">
                <path class="elementor-shape-fill" d="M790.5,93.1c-59.3-5.3-116.8-18-192.6-50c-29.6-12.7-76.9-31-100.5-35.9c-23.6-4.9-52.6-7.8-75.5-5.3
				c-10.2,1.1-22.6,1.4-50.1,7.4c-27.2,6.3-58.2,16.6-79.4,24.7c-41.3,15.9-94.9,21.9-134,22.6C72,58.2,0,25.8,0,25.8V100h1000V65.3
				c0,0-51.5,19.4-106.2,25.7C839.5,97,814.1,95.2,790.5,93.1z"></path>
            </svg>
        </div>
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <div class="company-info-home company-info-home-one">
                            <p>Du kannst dich auf uns verlassen. Wir kennen das Business schon seit über 20 Jahren. Jeder Handgriff sitzt, unser weltumspannendes Netzwerk ist regelmässig in verschiedene Projekte involviert:</p>
                            <p>Dazu gehören unter anderem Podcasts, Corporate Videos, TV, Games, Apps, Hörbücher, oder e-Learnings.</p>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-6">
                        <div class="company-info-home company-info-home-two">
                            <p>Du kannst die Services einzeln beauftragen oder uns die komplette Produktion anvertrauen. Gerne erstellen wir dir ein individuelles Angebot.</p>
                            <p>Schreibe uns unten einfach eine Nachricht oder rufe an:</p>
                            <p>T+49-89-997429620</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Company Information Section Ends -->
    <!-- Important Accordion Section Starts -->
    <div class="container-fluid bg-imp-accordion-home">
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="wave-form-ih-accordion-home">
                            <img src="../assets/images/waveform.svg" class="img-responsive" alt="" />
                            <h2>Was sonst noch wichtig ist</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xs-12">
                        <div class="accordion-home">
                            <h4 class="active">All in one</h4>
                            <div>
                                <div class="imp-notes">
                                    <p>Eine Plattform – drei Lokalisierungsservices aus einer Hand: die Umsetzung komplexer Projekte bedarf keiner weiteren Koordination mehrerer Dienstleistungspartner mehr.</p>
                                </div>
                            </div>
                            <h4>Datensicherheit</h4>
                            <div>
                                <div class="imp-notes">
                                    <p>Wir verschlüsseln alle Daten – sowohl während der Übertragung als auch dort, wo sie auf unseren geschützten Servern gespeichert sind. Deine Dateien werden mit TLS 1.2-Verschlüsselung sicher gespeichert und übertragen.</p>
                                </div>
                            </div>
                            <h4>Kurze Lieferzeiten</h4>
                            <div>
                                <div class="imp-notes">
                                    <p>Auftragsbezogene Prozesse wie Bestellung, Kalkulation oder Dateiverwaltung wurden weitestgehend automatisiert und verkürzen damit die Projektlaufzeit.</p>
                                </div>
                            </div>
                            <h4>Preise</h4>
                            <div>
                                <div class="imp-notes">
                                    <p>Durch unser großes Ordervolumen können wir sehr attraktive Konditionen anbieten. Die kalkulierten Kosten enthalten sämtliche Leistungen wie z.B. Sprecherhonorare, Buyouts und Projektmanagement.</p>
                                </div>
                            </div>
                            <h4>Projektmanagement</h4>
                            <div>
                                <div class="imp-notes">
                                    <p>Unsere Projektmanager gewährleisten eine reibungslose Umsetzung. Durch die gleichzeitige Übersetzung und Vertonung in mehreren Sprachen können die Lieferzeiten verkürzt werden.</p>
                                </div>
                            </div>
                            <h4>Erfahrung</h4>
                            <div>
                                <div class="imp-notes">
                                    <p>Profitiere von unserem langjährigen Know-how. Mit mehr als 25 Jahren Erfahrung in der Lokalisierung sorgen wir dafür, dass deine Projekte zuverlässig, professionell und zum bestmöglichen Preis realisiert werden.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Important Accordion Section Ends -->
    <!-- Price Table Section Starts -->
    <div class="container-fluid bg-price-table-home">
        <div class="row">
            <div class="container">
                <div class="row remove-margin-price-table">
                    <div class="col-sm-4 col-md-4 col-lg-4 remove-padding-price-table">
                        <div class="panel-tts-bap">
                            <div class="panel-tts-bap-heading-desc text-center">
                                <h3>Transkription</h3>
                                <p>100% manuell</p>
                            </div>
                            <div class="panel-tts-bap-price">
                                <p>ab 0,99€<span>/min</span></p>
                            </div>
                            <ul class="tts-bap-listing tts-listing-home">
                                <li>80 Ausgangssprachen</li>
                                <li>Zeitstempel verfügbar</li>
                                <li>Textglättung verfügbar</li>
                                <li>Vorbereitet für Übersetzung</li>
                                <li>3-Tage Garantielieferung + 0,49€ / min</li>
                                <li>24 h Express-Lieferung + 0,99€ / Min.</li>
                            </ul>
                            <div class="tts-bap-button text-center">
                                <a href="#" class="btn-tts-bap btn-tts-one-three">Mediendatei hochladen</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 remove-padding-price-table">
                        <div class="panel-tts-bap blue">
                            <div class="panel-tts-bap-heading-desc text-center">
                                <h3>Übersetzung</h3>
                                <p>Neuronale KI plus Mensch</p>
                            </div>
                            <div class="panel-tts-bap-price">
                                <p>ab 0,036€<span>/Wort</span></p>
                            </div>
                            <ul class="tts-bap-listing tts-listing-home blue">
                                <li>76 Zielsprachen</li>
                                <li>ISO 17100:2015 zertifiziert</li>
                                <li>Qualifizierte Fachübersetzer</li>
                                <li>Erstklassige Qualität</li>
                                <li>Auf Wunsch inkl. Proofreading</li>
                                <li>Sofortige Preisermittlung</li>
                            </ul>
                            <div class="tts-bap-button text-center">
                                <a href="#" class="btn-tts-bap btn-tts-two">Dokument hochladen</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-4 col-md-4 col-lg-4 remove-padding-price-table">
                        <div class="panel-tts-bap">
                            <div class="panel-tts-bap-heading-desc text-center">
                                <h3>Sprachproduktion</h3>
                                <p>Professionelle Studioqualität</p>
                            </div>
                            <div class="panel-tts-bap-price">
                                <p>ab 26€<span>/min</span></p>
                            </div>
                            <ul class="tts-bap-listing tts-listing-home">
                                <li>70 + Sprachen</li>
                                <li>2.500 + professionelle Sprecher</li>
                                <li>Kurze Lieferzeiten</li>
                                <li>Erstklassige Audio Qualität</li>
                                <li>Auf Wunsch inkl. Audiobearbeitung</li>
                                <li>Sprechercasting + Buchung online</li>
                            </ul>
                            <div class="tts-bap-button text-center">
                                <a href="#" class="btn-tts-bap btn-tts-one-three">Skript hochladen</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Price Table Section Ends -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Works/Work/Germany(Laravel)/current code/aivox(laravel)/resources/views/home.blade.php ENDPATH**/ ?>