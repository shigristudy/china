<!-- Footer Section Starts -->
<div class="container-fluid bg-footer-home">
    <div class="row">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4>About us</h4>
                        <div class="footer-about-description">
                            <p>Originally founded as "pro-tone audio agency", we have been specializing in audio localizations in over 70 languages since 2001. Our clients include European and American Fortune Global 500 companies from various industries as well as agencies, media houses and publishing houses. The newly developed AIVOX platform expands our portfolio by the services Transcription and Translation, where our employees are supported by the selective use of artificial intelligence and neural networks. Project-related processes such as ordering, calculation or file management have been extensively automated. The company is 100% owned by the management.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4>Services</h4>
                        <ul class="footer-services-listing">
                            <li><a href="transcription.html">Transcription</a></li>
                            <li><a href="translation.html">Translation</a></li>
                            <li><a href="speech-production.html">Voiceover</a></li>
                        </ul>
                        <h4>Legal information</h4>
                        <ul class="footer-legal-listing">
                            <li><a href="#">Imprint</a></li>
                            <li><a href="#">General terms and conditions of business</a></li>
                            <li><a href="#">Privacy policy</a></li>
                        </ul>
                    </div>
                </div>
                <div class="visible-sm clearfix"></div>
                <div class="col-sm-6 col-md-4 col-lg-4">
                    <div class="footer-heading">
                        <h4>Contact us</h4>
                        <form>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="Your name" />
                            </div>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="Your e-mail" />
                            </div>
                            <div class="form-group-footer">
                                <input type="text" class="form-control form-control-footer" placeholder="Your message" />
                            </div>
                            <div class="form-group-footer">
                                <input type="submit" class="btn-send" value="Send" />
                            </div>
                        </form>
                        <div class="footer-form-description">
                            <p>If you have questions about a project or individual requirements, please contact us. We will be happy to help you. If you already have an order number, please enter it in the form text. We will answer your questions as soon as possible.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer Section Ends -->
<!-- Copyright Section Starts -->
<div class="container-fluid bg-copyright-home">
    <div class="row">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="copyright-info text-center">
                        <p>We <i class="far fa-heart"></i> localization. Copyright 2020. AIVOX. All rights reserved.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Copyright Section Ends -->
<!-- Scroll To Top Section Starts -->
<div class="scroll-to-top-home">
    <a href="#home">
        <i class="fas fa-chevron-up"></i>
    </a>
</div>
<!-- Scroll To Top Section Ends --><?php /**PATH /Volumes/Works/Work/Germany(Laravel)/aivox/aivox(laravel)/resources/views/includes/footer.blade.php ENDPATH**/ ?>