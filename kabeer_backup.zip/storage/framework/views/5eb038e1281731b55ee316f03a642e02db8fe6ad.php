<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0" />
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicon Icon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon" />
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" type="image/x-icon" />
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>" type="text/css" />
    <!-- Bootstrap-3 Minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" type="text/css" />
    <!-- Slick Slider CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick.min.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/slick-theme.min.css')); ?>" type="text/css" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" type="text/css" />
    <!-- Media CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/media.css')); ?>" type="text/css" />
</head>
<body>
<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- jQuery Library -->
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<!-- Slick Slide JS -->
<script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
<!-- Home Page JS -->
<script src="<?php echo e(asset('assets/js/home-page.js')); ?>"></script>
<!-- Accordion JS -->
<script src="<?php echo e(asset('assets/js/accordion.js')); ?>"></script>
<!-- Custom JS -->
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>
</html><?php /**PATH /Volumes/Works/Work/Germany(Laravel)/current code/aivox(laravel)/resources/views/layouts/default.blade.php ENDPATH**/ ?>