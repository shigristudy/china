<?php $__env->startSection('title', 'REGISTER'); ?>
<?php $__env->startSection('style'); ?>
    <!-- Coutry Code CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/intlTelInput.css')); ?>" type="text/css" />
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
    <style>
        .js-hidden {
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Registration Form Section Starts -->
    <div class="container-fluid bg-regis-pg">
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="regis-ihd-rp text-center">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path d="M208 96C93.1 96 0 189.1 0 304s93.1 208 208 208 208-93.1 208-208S322.9 96 208 96zm0 384c-97 0-176-79-176-176s79-176 176-176 176 79 176 176-79 176-176 176zm75.8-130.7C265 371.4 237.4 384 208 384s-57-12.6-75.8-34.6c-5.7-6.7-15.9-7.5-22.5-1.8-6.8 5.8-7.5 15.8-1.8 22.6C132.7 399.3 169.2 416 208 416s75.3-16.7 100.2-45.9c5.8-6.7 4.9-16.8-1.8-22.6-6.6-5.6-16.8-4.9-22.6 1.8zM144 280c13.3 0 24-10.7 24-24s-10.7-24-24-24-24 10.7-24 24 10.7 24 24 24zm128 0c13.3 0 24-10.7 24-24s-10.7-24-24-24-24 10.7-24 24 10.7 24 24 24zM632 96h-88V8c0-4.4-3.6-8-8-8h-16c-4.4 0-8 3.6-8 8v88h-88c-4.4 0-8 3.6-8 8v16c0 4.4 3.6 8 8 8h88v88c0 4.4 3.6 8 8 8h16c4.4 0 8-3.6 8-8v-88h88c4.4 0 8-3.6 8-8v-16c0-4.4-3.6-8-8-8z"></path></svg>
                            <h1><?php echo e(__('words.web.sign_up.head')); ?></h1>
                            <p><?php echo e(__('words.web.sign_up.des')); ?></p>
                        </div>
                    </div>
                </div>
                <form class="form-horizontal form-horizontal-rp" action="<?php echo e(route('register')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.company')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('company')): ?>
                                    <p class="error_message"><?php echo e($errors->first('company')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="company" required="" oninvalid="this.setCustomValidity('Please Enter valid Company')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.contact')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('contact_name')): ?>
                                    <p class="error_message"><?php echo e($errors->first('contact_name')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="contact_name" required="" oninvalid="this.setCustomValidity('Please Enter valid contact name')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.email')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('email')): ?>
                                        <p class="error_message"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                    <input type="email" class="form-control form-control-rl" name="email" required="" oninvalid="this.setCustomValidity('Please Enter valid email')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.phone')); ?></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" name="phone_number"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.street')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('street')): ?>
                                        <p class="error_message"><?php echo e($errors->first('street')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="street" required="" oninvalid="this.setCustomValidity('Please Enter valid street')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.house_number')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('house_number')): ?>
                                        <p class="error_message"><?php echo e($errors->first('house_number')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="house_number" oninvalid="this.setCustomValidity('Please Enter valid House Number')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.zip')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('zip_code')): ?>
                                        <p class="error_message"><?php echo e($errors->first('zip_code')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="zip_code" required="" oninvalid="this.setCustomValidity('Please Enter valid Zip Code')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.city')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('city')): ?>
                                        <p class="error_message"><?php echo e($errors->first('city')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="city" required="" oninvalid="this.setCustomValidity('Please Enter valid City')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.federal_state')); ?></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('federal_state')): ?>
                                        <p class="error_message"><?php echo e($errors->first('federal_state')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="federal_state"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.country')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('country')): ?>
                                        <p class="error_message"><?php echo e($errors->first('country')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="country" required="" oninvalid="this.setCustomValidity('Please Enter valid Country')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.tax_id')); ?></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" name="tax_id"/>
                                    <p class="set-example">z.B. DE123456789</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.mobile')); ?></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="tel" name="phone" class="form-control form-control-rl" placeholder="" id="phone" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.username')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('username')): ?>
                                        <p class="error_message"><?php echo e($errors->first('username')); ?></p>
                                    <?php endif; ?>
                                    <input type="text" class="form-control form-control-rl" name="username" required="" oninvalid="this.setCustomValidity('Please Enter valid Username')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.password')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <?php if($errors->has('password')): ?>
                                        <p class="error_message"><?php echo e($errors->first('password')); ?></p>
                                    <?php endif; ?>
                                    <input type="password" class="password-strength__input form-control form-control-rl" name="password" id="password-input" required="" oninvalid="this.setCustomValidity('Please Enter valid Password')"
                                           oninput="setCustomValidity('')"/>
                                    <div class="input-group-append">
                                        <button class="password-strength__visibility btn btn-outline-secondary" type="button"><span class="password-strength__visibility-icon" data-visible="hidden"><i class="fas fa-eye-slash"></i></span><span class="password-strength__visibility-icon js-hidden" data-visible="visible"><i class="fas fa-eye"></i></span></button>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.sign_up.repeat_pwd')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="password" class="form-control form-control-rl" name="password_confirmation" required="" oninvalid="this.setCustomValidity('Please Enter Confirm password')"
                                           oninput="setCustomValidity('')"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <input type="button" class="btn-gen-pwd password_generator" value="Generate Password" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <div class="pwd-strength"><?php echo e(__('words.web.sign_up.indicator')); ?></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <div class="pwd-hint-desc">
                                        <p><?php echo e(__('words.web.sign_up.pwd_hint')); ?></p>
                                        <ul class="pwd-hint-listing">
                                            <li><?php echo e(__('words.web.sign_up.hint_des_1')); ?></li>
                                            <li><?php echo e(__('words.web.sign_up.hint_des_2')); ?></li>
                                            <li><?php echo e(__('words.web.sign_up.hint_des_3')); ?></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <label class="password-to-email">
                                        <input type="checkbox" name="pwd-to-email" class="pwd-to-email"/>
                                        <span></span>
                                        <span><?php echo e(__('words.web.sign_up.send_email')); ?></span>
                                    </label>
                                    <p class="check-to-activate"><?php echo e(__('words.web.sign_up.send_email_hint')); ?></p>
                                    <label class="terms-conditions">
                                        <input type="checkbox" name="terms-conditions" class="terms-conditions" required/>
                                        <span></span>
                                        <span><?php echo e(__('words.web.sign_up.terms')); ?><a href="#">Terms and conditions</a></span>
                                    </label>
                                    <label class="privacy-policy">
                                        <input type="checkbox" name="privacy-policy" class="privacy-policy" required/>
                                        <span></span>
                                        <span><?php echo e(__('words.web.sign_up.policy')); ?><a href="#">Privacy policy</a></span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <input type="submit" class="btn-registration" value="<?php echo e(__('words.web.sign_up.submit_registration')); ?>" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <div class="field-required">
                                        <p><?php echo e(__('words.web.sign_up.mandatory_field')); ?> <a href="#">"<?php echo e(__('words.web.sign_up.field_name')); ?>"</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Registration Form Section Ends -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Country Codde JS -->
    <script src="<?php echo e(asset('assets/js/intlTelInput.js')); ?>"></script>
    <!-- Registration Page JS -->
    <script src="<?php echo e(asset('assets/js/registration.js')); ?>"></script>

    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/password.js')); ?>"></script>
    <script>
        $(".password_generator").click(function () {
            $("#password-input").val(password.generate());
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Work/php/laravel/aivox(laravel)/resources/views/Web/pages/auth/register.blade.php ENDPATH**/ ?>