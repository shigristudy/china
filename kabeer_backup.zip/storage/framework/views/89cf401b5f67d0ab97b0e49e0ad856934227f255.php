<?php $__env->startSection('title', 'REGISTER'); ?>
<?php $__env->startSection('style'); ?>
    <!-- Coutry Code CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/intlTelInput.css')); ?>" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Registration Form Section Starts -->
    <div class="container-fluid bg-regis-pg" >
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="regis-ihd-rp text-center">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path d="M208 96C93.1 96 0 189.1 0 304s93.1 208 208 208 208-93.1 208-208S322.9 96 208 96zm0 384c-97 0-176-79-176-176s79-176 176-176 176 79 176 176-79 176-176 176zm75.8-130.7C265 371.4 237.4 384 208 384s-57-12.6-75.8-34.6c-5.7-6.7-15.9-7.5-22.5-1.8-6.8 5.8-7.5 15.8-1.8 22.6C132.7 399.3 169.2 416 208 416s75.3-16.7 100.2-45.9c5.8-6.7 4.9-16.8-1.8-22.6-6.6-5.6-16.8-4.9-22.6 1.8zM144 280c13.3 0 24-10.7 24-24s-10.7-24-24-24-24 10.7-24 24 10.7 24 24 24zm128 0c13.3 0 24-10.7 24-24s-10.7-24-24-24-24 10.7-24 24 10.7 24 24 24zM632 96h-88V8c0-4.4-3.6-8-8-8h-16c-4.4 0-8 3.6-8 8v88h-88c-4.4 0-8 3.6-8 8v16c0 4.4 3.6 8 8 8h88v88c0 4.4 3.6 8 8 8h16c4.4 0 8-3.6 8-8v-88h88c4.4 0 8-3.6 8-8v-16c0-4.4-3.6-8-8-8z"></path></svg>
                            <h1>Profile</h1>
                            <p>Check your profile</p>
                        </div>
                    </div>
                </div>
                <form class="form-horizontal form-horizontal-rp" action="<?php echo e(route('profile_update')); ?>">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Company or customer name <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" name="company" class="form-control" value="<?php echo e($user->company? $user->company: 'Empty Value'); ?>" placeholder="Company or Customer name"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Contact name <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                   <input class="form-control" name="contact_name" type="text" value="<?php echo e($user->contact_name? $user->contact_name: 'Empty Value'); ?>" placeholder="Contact Name"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Email <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" name="email" type="email" value="<?php echo e($user->email ? $user->email : 'Empty value'); ?>" placeholder="Email"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Phone</label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" name="phone_number" type="text" value="<?php echo e($user->phone_number ? $user->phone_number : 'Empty value'); ?>" placeholder="Phone number"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Street <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="street" value="<?php echo e($user->street ? $user->street : 'Empty value'); ?>" placeholder="Street"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">House number <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="house_number" value="<?php echo e($user->house_number ? $user->house_number : 'Empty Value'); ?>" placeholder="House number"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">ZIP <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="zip_code" value="<?php echo e($user->zip_code ? $user->zip_code : 'Empty Value'); ?>" placeholder="Zip"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">City <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="city" value="<?php echo e($user->city ? $user-> city : 'Empty Value'); ?>" placeholder="City"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Federal state</label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="federal_state" value="<?php echo e($user->federal_state ? $user->federal_state : 'Empty Value'); ?>" placeholder="Federal State"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Country <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="country" value="<?php echo e($user->country ? $user->country : 'Empty Value'); ?>" placeholder="Country" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Sales tax ID</label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="tax_id" value="<?php echo e($user->tax_id ? $user->tax_id : 'Empty Value'); ?>" placeholder="Tax Id"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Username <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="username" value="<?php echo e($user->username ? $user->username : 'Empty Value'); ?>" placeholder="Username" />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row text-center">
                        <button class="btn btn-primary" type="submit">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Registration Form Section Ends -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Country Codde JS -->
    <script src="<?php echo e(asset('assets/js/intlTelInput.js')); ?>"></script>
    <!-- Registration Page JS -->
    <script src="<?php echo e(asset('assets/js/registration.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Work/php/laravel/aivox(laravel)/resources/views/web/pages/user/profile.blade.php ENDPATH**/ ?>