<!-- Preloader Section Starts -->
<div class="loader-wrapper">
    <div class="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div>
<!-- Preloader Section Ends -->
<!-- BG Blur Section Starts -->
<div class="bg-blur"></div>
<!-- BG Blur Section Ends -->
<!-- Mobile Navigation Menu Section Starts -->
<div class="fixed-navbar-menu-mob-tab">
    <ul class="menu-listing-mob-tab">
        <li class="<?php echo e((request()->is('/')) ? 'active' : ''); ?>"><a href="/">Home</a></li>
        <li class="<?php echo e((request()->is('transcription')) ? 'active' : ''); ?>"><a href="<?php echo e(route('transcription')); ?>">Transcription</a></li>
        <li class="<?php echo e((request()->is('translation')) ? 'active' : ''); ?>"><a href="<?php echo e(route('translation')); ?>">Translation</a></li>
        <li class="<?php echo e((request()->is('voiceover')) ? 'active' : ''); ?>"><a href="<?php echo e(route('voiceover')); ?>">Voiceover</a></li>
        <li class="<?php echo e((request()->is('login')) || (request()->is('register')) ? 'active' : ''); ?>">
            <a href="#">Account <i class="fas fa-chevron-down"></i></a>
            <ul class="sub-menu-listing-mob-tab">
                <li><a href="<?php echo e(route('login')); ?>">LogIn</a></li>
                <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
            </ul>
        </li>
        <li>
            <a href="#">DE <i class="fas fa-chevron-down"></i></a>
            <ul class="sub-menu-listing-mob-tab">
                <li><a href="#">EN</a></li>
            </ul>
        </li>
    </ul>
    <div class="search-in-mob-tab">
        <i class="fas fa-search"></i>
        <p>Search</p>
    </div>
</div>
<!-- Mobile Navigation Menu Section Ends -->
<!-- Mobile Logo and Hamburger Menu Section Starts -->
<div class="container-fluid bg-logo-hamburger-menu-mob-tab-home">
    <div class="row flex-align-center-desktop">
        <div class="col-xs-6">
            <div class="header-logo-mob-tab">
                <a href="">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-responsive" alt="" />
                </a>
            </div>
        </div>
        <div class="col-xs-6">
            <div class="burger-menu text-right">
                <i class="fa fa-bars"></i>
            </div>
        </div>
    </div>
</div>
<!-- Mobile Logo and Hamburger Menu Section Ends -->
<!-- Search Section Starts -->
<div class="fixed-search-pop-up-home">
    <div class="search-pop-up-home">
        <div class="search-pop-up-heading-home text-center">
            <p>Start Typing and Press Enter To Search</p>
            <form>
                <div class="input-group">
                    <input type="text" class="form-control form-control-search-home" />
                    <div class="input-group-btn">
                        <button class="btn btn-search-home" type="submit">
                            <i class="fa fa-search"></i>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="search-pop-up-close-home">
        <img src="<?php echo e(asset('assets/images/close.png')); ?>" class="img-responsive" alt="" />
    </div>
</div>
<!-- Search Section Ends -->
<!-- Desktop Logo and Navigationbar Menu Section Starts -->
<div class="container-fluid bg-logo-navbar-desktop-home">
    <div class="row">
        <div class="container">
            <div class="row flex-align-center-desktop">
                <div class="col-sm-3 col-md-2 col-lg-3">
                    <div class="header-desktop-logo">
                        <a href="">
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-responsive" alt="" />
                        </a>
                    </div>
                </div>
                <div class="col-sm-9 col-md-10 col-lg-9">
                    <div class="navbar-menu-desktop">
                        <ul class="menu-listing text-right">
                            <li class="<?php echo e((request()->is('/')) ? 'active' : ''); ?>"><a href="/">Home</a></li>
                            <li class="<?php echo e((request()->is('transcription')) ? 'active' : ''); ?>"><a href="<?php echo e(route('transcription')); ?>">Transcription</a></li>
                            <li class="<?php echo e((request()->is('translation')) ? 'active' : ''); ?>"><a href="<?php echo e(route('translation')); ?>">Translation</a></li>
                            <li class="<?php echo e((request()->is('voiceover')) ? 'active' : ''); ?>"><a href="<?php echo e(route('voiceover')); ?>">Voiceover</a></li>
                            <li class="<?php echo e((request()->is('login')) || (request()->is('register')) ? 'active' : ''); ?>">
                                <a href="#">Account <i class="fas fa-chevron-down"></i></a>
                                <ul class="sub-menu-listing">
                                    <li><a href="<?php echo e(route('login')); ?>">LogIn</a></li>
                                    <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                                </ul>
                            </li>
                            
                            
                            
                            
                            
                                
                                
                                    
                                    
                                
                            
                            <li>
                                <a href="#">DE <i class="fas fa-chevron-down"></i></a>
                                <ul class="sub-menu-listing">
                                    <li><a href="#">EN</a></li>
                                </ul>
                            </li>
                            <li><a href="#"><i class="fas fa-search header-search"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Desktop Logo and Navigationbar Menu Section Ends --><?php /**PATH /Volumes/Work/php/laravel/aivox(laravel)/resources/views/includes/header.blade.php ENDPATH**/ ?>