<?php $__env->startSection('title', 'REGISTER'); ?>
<?php $__env->startSection('style'); ?>
    <!-- Coutry Code CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/intlTelInput.css')); ?>" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Registration Form Section Starts -->
    <div class="container-fluid bg-register-pg" >
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="register-ihd-rp text-left">

                            <h1><?php echo e(__('words.web.profile.profile_head')); ?></h1>
                            <p></p>
                        </div>
                    </div>
                </div>
                <form class="form-horizontal form-horizontal-rp" action="<?php echo e(route('profile_update')); ?>">
                    <div class="row">
                        <div class="col-xs-12 profile">
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.company')); ?> <span></span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" name="company" class="form-control" value="<?php echo e($user->company? $user->company: ''); ?>" placeholder=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.first_name')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="first_name" value="<?php echo e($user->first_name ? $user->first_name : ''); ?>" placeholder="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.last_name')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="last_name" value="<?php echo e($user->last_name ? $user->last_name : ''); ?>" placeholder="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.email')); ?> <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" name="email" type="email" value="<?php echo e($user->email ? $user->email : ''); ?>" placeholder=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.phone')); ?></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" name="phone_number" type="text" value="<?php echo e($user->phone_number ? $user->phone_number : ''); ?>" placeholder=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.street')); ?> <span></span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="street" value="<?php echo e($user->street ? $user->street : ''); ?>" placeholder=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.house_number')); ?> <span></span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="house_number" value="<?php echo e($user->house_number ? $user->house_number : ''); ?>" placeholder=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.zip')); ?> <span></span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="zip_code" value="<?php echo e($user->zip_code ? $user->zip_code : ''); ?>" placeholder=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.city')); ?> <span></span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="city" value="<?php echo e($user->city ? $user-> city : ''); ?>" placeholder=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.federal_state')); ?></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="federal_state" value="<?php echo e($user->federal_state ? $user->federal_state : ''); ?>" placeholder=""/>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.country')); ?> <span></span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="country" value="<?php echo e($user->country ? $user->country : ''); ?>" placeholder="" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3"><?php echo e(__('words.web.profile.tax')); ?></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input class="form-control" type="text" name="tax_id" value="<?php echo e($user->tax_id ? $user->tax_id : ''); ?>" placeholder=""/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row text-center profile_btn">
                        <button class="btn btn-primary" type="submit"><?php echo e(__('words.web.profile.update')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Registration Form Section Ends -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Country Codde JS -->
    <script src="<?php echo e(asset('assets/js/intlTelInput.js')); ?>"></script>
    <!-- Registration Page JS -->
    <script src="<?php echo e(asset('assets/js/registration.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/aivox.de/httpdocs/resources/views/web/pages/user/profile.blade.php ENDPATH**/ ?>