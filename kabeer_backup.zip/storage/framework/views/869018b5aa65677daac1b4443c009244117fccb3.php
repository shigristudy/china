<?php $__env->startSection('title', 'REGISTER'); ?>
<?php $__env->startSection('style'); ?>
    <!-- Coutry Code CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/intlTelInput.css')); ?>" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Registration Form Section Starts -->
    <div class="container-fluid bg-regis-pg">
        <div class="row">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="regis-ihd-rp text-center">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512"><path d="M208 96C93.1 96 0 189.1 0 304s93.1 208 208 208 208-93.1 208-208S322.9 96 208 96zm0 384c-97 0-176-79-176-176s79-176 176-176 176 79 176 176-79 176-176 176zm75.8-130.7C265 371.4 237.4 384 208 384s-57-12.6-75.8-34.6c-5.7-6.7-15.9-7.5-22.5-1.8-6.8 5.8-7.5 15.8-1.8 22.6C132.7 399.3 169.2 416 208 416s75.3-16.7 100.2-45.9c5.8-6.7 4.9-16.8-1.8-22.6-6.6-5.6-16.8-4.9-22.6 1.8zM144 280c13.3 0 24-10.7 24-24s-10.7-24-24-24-24 10.7-24 24 10.7 24 24 24zm128 0c13.3 0 24-10.7 24-24s-10.7-24-24-24-24 10.7-24 24 10.7 24 24 24zM632 96h-88V8c0-4.4-3.6-8-8-8h-16c-4.4 0-8 3.6-8 8v88h-88c-4.4 0-8 3.6-8 8v16c0 4.4 3.6 8 8 8h88v88c0 4.4 3.6 8 8 8h16c4.4 0 8-3.6 8-8v-88h88c4.4 0 8-3.6 8-8v-16c0-4.4-3.6-8-8-8z"></path></svg>
                            <h1>Sign-up</h1>
                            <p>Please fill out the form completely.</p>
                        </div>
                    </div>
                </div>
                <form class="form-horizontal form-horizontal-rp">
                    <div class="row">
                        <div class="col-xs-12">
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Company or customer name <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Contact name <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Email <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="email" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Phone</label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Street <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">House number <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">ZIP <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">City <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Federal state</label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Country <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Sales tax ID</label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                    <p class="set-example">z.B. DE123456789</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Mobile phone</label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="tel" name="phone" class="form-control form-control-rl" placeholder="" id="phone" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Username <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Password <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-sm-3 col-md-3 col-lg-3">Repeat password <span>*</span></label>
                                <div class="col-sm-9 col-md-9 col-lg-9">
                                    <input type="text" class="form-control form-control-rl" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <input type="button" class="btn-gen-pwd" value="Generate Password" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <div class="pwd-strength">Strength indicator</div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <div class="pwd-hint-desc">
                                        <p>Password hint:</p>
                                        <ul class="pwd-hint-listing">
                                            <li>- Should contain at least 6 characters.</li>
                                            <li>- Must have at least the medium safety level.</li>
                                            <li>- Should contain numbers.</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <label class="password-to-email">
                                        <input type="checkbox" name="pwd-to-email" class="pwd-to-email" />
                                        <span></span>
                                        <span>Send this password to email.</span>
                                    </label>
                                    <p class="check-to-activate">Check to activate</p>
                                    <label class="terms-conditions">
                                        <input type="checkbox" name="terms-conditions" class="terms-conditions" />
                                        <span></span>
                                        <span>I accept the general terms and conditions. <a href="#">Terms and conditions</a></span>
                                    </label>
                                    <label class="privacy-policy">
                                        <input type="checkbox" name="privacy-policy" class="privacy-policy" />
                                        <span></span>
                                        <span>I accept the privacy policy <a href="#">Privacy policy</a></span>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <input type="submit" class="btn-registration" value="SUBMIT REGISTRATION" disabled="disabled" />
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
                                    <div class="field-required">
                                        <p>A mandatory field is empty: <a href="#">"Company or customer name"</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Registration Form Section Ends -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <!-- Country Codde JS -->
    <script src="<?php echo e(asset('assets/js/intlTelInput.js')); ?>"></script>
    <!-- Registration Page JS -->
    <script src="<?php echo e(asset('assets/js/registration.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Work/php/laravel/aivox(laravel)/resources/views/pages/auth/register.blade.php ENDPATH**/ ?>