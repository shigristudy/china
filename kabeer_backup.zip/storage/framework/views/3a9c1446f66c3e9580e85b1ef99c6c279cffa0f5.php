<?php $__env->startSection('title', 'ORDER'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('backend/plugins/sweetalert/sweetalert.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- trans Form Section Starts -->
    <div class="container-fluid instant-quote-form-wrapper">
        <div class="row">
            <div class="container">
                <h2 class="mb-5">Order Processing</h2>
                <div class="col-sm-12 instant-quote-form">

                    <form data-select2-id="13" id="order_form">
                        <input type="hidden" value="<?php echo e($data[0]->id); ?>" id="order_data_id">
                        <input type="hidden" value="<?php echo e($data[0]->service_id); ?>" id="service_id">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Current File Name:</label>
                                    <h2><?php echo e($data[0]->orig_name); ?></h2>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label>Service Type:</label>
                                <h3><?php echo e($data[0]->service->name); ?></h3>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4" data-select2-id="162">
                                <div class="select-01" data-select2-id="161">
                                    <div class="form-group" data-select2-id="160">
                                        <label for="">From</label>
                                        <select id="sourceLanguage" class="form-control select2-hidden-accessible"
                                                data-select2-id="sourceLanguage" tabindex="-1" aria-hidden="true">
                                            <?php $__currentLoopData = $data_lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-selected2-id="<?php echo e($item->id); ?>"
                                                        value="<?php echo e($item->id); ?>"><?php echo e($item->lang); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="select-01" data-select2-id="12">
                                    <div id="divTargetLanguage" class="form-group" data-select2-id="divTargetLanguage">
                                        <!--<label for="">To <a href="" data-toggle="modal" data-target="#modalLanguages">Add Mutliple languages</a></label>
                                        onclick="ResetValues()"-->
                                        <label id="lblTo" for="">To
                                            <a href="#" id="aMultiple" data-toggle="modal" data-target="#multiple-lang">Add
                                                Mutliple languages</a>
                                        </label>
                                        <select class="form-control select2-hidden-accessible" id="targetLanguage"
                                                data-select2-id="targetLanguage" tabindex="-1" aria-hidden="true">
                                            <?php $__currentLoopData = $data_lang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option data-selected2-id="<?php echo e($item->id); ?>"
                                                        value="<?php echo e($item->id); ?>"><?php echo e($item->lang); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <label for=" ">Word Count</label>
                                <div class="word-count-or-upload">
                                    <input type="text" placeholder="Word count" id="word_count" value="1000">
                                    <p class="error_message">Required the word Count</p>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="select-04">
                                    <div class="form-group">
                                        <label for="">Subject</label>
                                        <select class="form-control select2-hidden-accessible" id="targetSubject"
                                                data-select2-id="targetSubject" tabindex="-1" aria-hidden="true">
                                            <option value="" disabled="">Subject</option>
                                            <option value="accounting_finance">Accounting &amp; Finance</option>
                                            <option value="adwords">AdWords Campaigns</option>
                                            <option value="aerospace_defence">Aerospace / Defence</option>
                                            <option value="architecture">Architecture</option>
                                            <option value="art">Art</option>
                                            <option value="automotive">Automotive</option>
                                            <option value="certificates_diplomas_licences_cv_etc">Certificates,
                                                diplomas, licences , cv's, etc
                                            </option>
                                            <option value="chemical">Chemical</option>
                                            <option value="civil_engineering_construction">Civil Engineering /
                                                Construction
                                            </option>
                                            <option value="corporate_social_responsibility">Corporate Social
                                                Responsibility
                                            </option>
                                            <option value="cosmetics">Cosmetics</option>
                                            <option value="culinary">Culinary</option>
                                            <option value="electronics_electrical_engineering">Electronics / Electrical
                                                Engineering
                                            </option>
                                            <option value="energy_power_generation_oil_gas">Energy / Power generation /
                                                Oil &amp; Gas
                                            </option>
                                            <option value="environment">Environment</option>
                                            <option value="fashion">Fashion</option>
                                            <option selected="" value="general" data-select2-id="8">General</option>
                                            <option value="general_business_commerce">General Business / Commerce
                                            </option>
                                            <option value="history_archaeology">History / Archaeology</option>
                                            <option value="information_technology">Information Technology</option>
                                            <option value="insurance">Insurance</option>
                                            <option value="internet_e-commerce">Internet, e-commerce</option>
                                            <option value="legal_documents_contracts">Legal documents / Contracts
                                            </option>
                                            <option value="literary_translations">Literary Translations</option>
                                            <option value="marketing_advertising_material_public_relations">Marketing
                                                &amp; Advertising material / Public Relations
                                            </option>
                                            <option value="matematics_and_physics">Mathematics and Physics</option>
                                            <option value="mechanical_manufacturing">Mechanical / Manufacturing</option>
                                            <option value="media_journalism_publishing">Media / Journalism /
                                                Publishing
                                            </option>
                                            <option value="medical_pharmaceutical">Medical / Pharmaceutical</option>
                                            <option value="music">Music</option>
                                            <option value="private_correspondence_letters">Private Correspondence,
                                                Letters
                                            </option>
                                            <option value="religion">Religion</option>
                                            <option value="science">Science</option>
                                            <option value="shipping_sailing_maritime">Shipping / Sailing / Maritime
                                            </option>
                                            <option value="social_science">Social Science</option>
                                            <option value="telecommunications">Telecommunications</option>
                                            <option value="travel_tourism">Travel &amp; Tourism</option>
                                            <option value="games_viseogames_casino">Games / Video Games / Casino
                                            </option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4"></div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="">Delivery Type</label>
                                    <div class="delivery-input">
                                        <label>
                                            <input type="radio" id="delivery_type" value="1" name="delivery_type" style="width: 15px" checked> Mt +
                                            light review <br>
                                            <input type="radio" id="delivery_type" value="2" name="delivery_type"
                                                   style="width: 15px"> Proofreading

                                        </label>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                </div>
                            </div>
                            
                            
                            
                            
                        </div>
                        <div class="row">
                            <a href="#" class="trans-form-sub" id="order_submit">Order Now</a>
                        </div>
                    </form>
                    <!-- Modal -->
                    <!-- Multiple language modal -->
                    <div id="multiple-lang" class="modal fade" role="dialog">
                        <div class="modal-dialog">

                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">×</button>
                                    <div class="search-icon-right">
                                        <svg width="20px" height="20px" viewBox="0 0 20 20">
                                            <g stroke="none" stroke-width="1" class="icon__fill" fill-rule="evenodd">
                                                <g transform="translate(-2.000000, -2.000000)" fill-rule="nonzero">
                                                    <path d="M11,20 C6.02943725,20 2,15.9705627 2,11 C2,6.02943725 6.02943725,2 11,2 C15.9705627,2 20,6.02943725 20,11 C20,15.9705627 15.9705627,20 11,20 Z M11,18 C14.8659932,18 18,14.8659932 18,11 C18,7.13400675 14.8659932,4 11,4 C7.13400675,4 4,7.13400675 4,11 C4,14.8659932 7.13400675,18 11,18 Z M21.7071068,20.2928932 C22.0976311,20.6834175 22.0976311,21.3165825 21.7071068,21.7071068 C21.3165825,22.0976311 20.6834175,22.0976311 20.2928932,21.7071068 L15.9428932,17.3571068 C15.5523689,16.9665825 15.5523689,16.3334175 15.9428932,15.9428932 C16.3334175,15.5523689 16.9665825,15.5523689 17.3571068,15.9428932 L21.7071068,20.2928932 Z"></path>
                                                </g>
                                            </g>
                                        </svg>
                                    </div>
                                    <input type="text" placeholder="Search.." onkeyup="filter(this);"
                                           class="search-btn">
                                </div>
                                <div class="modal-body">
                                    <span class="d-multi-block">Most Popular</span>
                                    <div class="m-popular">
                                        <ul>
                                            <li>
                                                <a href="http://demo.kathaastu.com/aivox/trans-form.html">Frech(France)</a>
                                            </li>
                                            <li><a href="http://demo.kathaastu.com/aivox/trans-form.html">German</a>
                                            </li>
                                            <li><a href="http://demo.kathaastu.com/aivox/trans-form.html">Italian</a>
                                            </li>
                                            <li>
                                                <a href="http://demo.kathaastu.com/aivox/trans-form.html">Spanish(Spain)</a>
                                            </li>
                                        </ul>
                                    </div>
                                    <div id="divLang1" class="multi-columns">
                                        <ul id="ulLanguages1">
                                            <!--<li id="Italian">
                                                <a href="" onclick="return collectLanguages(this);">Italian</a>
                                                <div class="multi-column-tick"><svg width="18px" height="13px" viewBox="0 0 18 13"><g stroke="none" stroke-width="1" class="icon__fill" fill-rule="evenodd"><g transform="translate(-3.000000, -5.000000)" fill-rule="nonzero"><path d="M19.2928932,5.29289322 C19.6834175,4.90236893 20.3165825,4.90236893 20.7071068,5.29289322 C21.0976311,5.68341751 21.0976311,6.31658249 20.7071068,6.70710678 L9.70710678,17.7071068 C9.31658249,18.0976311 8.68341751,18.0976311 8.29289322,17.7071068 L3.29289322,12.7071068 C2.90236893,12.3165825 2.90236893,11.6834175 3.29289322,11.2928932 C3.68341751,10.9023689 4.31658249,10.9023689 4.70710678,11.2928932 L9,15.5857864 L19.2928932,5.29289322 Z"></path></g></g></svg></div>
                                            </li>-->
                                        </ul>
                                    </div>
                                    <div class="multi-columns">
                                        <ul id="ulLanguages2">
                                        </ul>
                                    </div>
                                    <div class="multi-columns">
                                        <ul id="ulLanguages3">
                                        </ul>
                                    </div>
                                    <div class="multi-columns">
                                        <ul id="ulLanguages4">
                                        </ul>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="modal-footer">
                                    <span id="languageCount"></span>&nbsp;

                                    <button type="button" class="btn btn-default" data-dismiss="modal">Done</button>
                                    <button id="btnReset" type="button" class="btn btn-default">Reset</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="myModal" class="modal fade" role="dialog" style="display: none;">
                        <div class="modal-dialog">
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">×</button>
                                    <h4 class="modal-title">Select the delivery date</h4>
                                </div>
                                <div class="modal-body">
                                    <p id="demo">Tue 18 August</p>

                                    <div id="divAuto" class="trans-radio selected">
                                        <label for="auto">
                                            <input type="radio" class="form-control" name="delivery" id="rdoAuto"
                                                   value="auto" style="width:15px">
                                            Auto (best price)
                                        </label>
                                    </div>
                                    <div id="divDelivery" class="trans-radio">
                                        <label for="byDate">Delivery guaranteed by</label>
                                        <input type="radio" class="form-control" name="delivery" id="rdoDate"
                                               value="byDate" style="width:15px">
                                        <div id="dateSel" class="flex-align-center-desktop dm-block">
                                            <select id="selDate" disabled="">
                                                <option value="Mon 06 July">Mon 06 July</option>
                                                <option value="Tue 07 July">Tue 07 July</option>
                                                <option value="Wed 08 July">Wed 08 July</option>
                                                <option value="Thu 09 July">Thu 09 July</option>
                                                <option value="Fri 10 July">Fri 10 July</option>
                                                <option value="Mon 13 July">Mon 13 July</option>
                                                <option value="Tue 14 July">Tue 14 July</option>
                                                <option value="Wed 15 July">Wed 15 July</option>
                                                <option value="Thu 16 July">Thu 16 July</option>
                                                <option value="Fri 17 July">Fri 17 July</option>
                                                <option value="Mon 20 July">Mon 20 July</option>
                                                <option value="Tue 21 July">Tue 21 July</option>
                                                <option value="Wed 22 July">Wed 22 July</option>
                                                <option value="Thu 23 July">Thu 23 July</option>
                                                <option value="Fri 24 July">Fri 24 July</option>
                                                <option value="Mon 27 July">Mon 27 July</option>
                                                <option value="Tue 28 July">Tue 28 July</option>
                                                <option value="Wed 29 July">Wed 29 July</option>
                                                <option value="Thu 30 July">Thu 30 July</option>
                                                <option value="Fri 31 July">Fri 31 July</option>
                                                <option value="Mon 03 August">Mon 03 August</option>
                                                <option value="Tue 04 August">Tue 04 August</option>
                                                <option value="Wed 05 August">Wed 05 August</option>
                                                <option value="Thu 06 August">Thu 06 August</option>
                                                <option value="Fri 07 August">Fri 07 August</option>
                                                <option value="Mon 10 August">Mon 10 August</option>
                                                <option value="Tue 11 August">Tue 11 August</option>
                                                <option value="Wed 12 August">Wed 12 August</option>
                                                <option value="Thu 13 August">Thu 13 August</option>
                                                <option value="Fri 14 August">Fri 14 August</option>
                                                <option value="Mon 17 August">Mon 17 August</option>
                                            </select>
                                            <select id="selTime" disabled="">
                                                <option value="09:00 AM">09:00 AM</option>
                                                <option value="11:00 AM">11:00 AM</option>
                                                <option value="01:00 PM">01:00 PM</option>
                                                <option value="03:00 PM">03:00 PM</option>
                                                <option value="05:00 PM">05:00 PM</option>
                                                <option value="07:00 PM">07:00 PM</option>
                                                <option value="09:00 PM">09:00 PM</option>
                                            </select>
                                            <select id="selZone" disabled="">
                                                <option value="SST">(SST) Midway Islands, American Samoa</option>
                                                <option value="HDT">(HDT) Hawaii, Tahiti, Cook Islands</option>
                                                <option value="AKST">(AKST) Alaska</option>
                                                <option value="PST">(PST) Pacific Standard Time (LA, Vancouver)</option>
                                                <option value="MST">(MST) Mountain Standard Time (Denver, SLC)</option>
                                                <option value="CST">(CST) Central Standard Time (Mexico, Chicago)
                                                </option>
                                                <option value="EST">(EST) Eastern Standard Time (NYC, Toronto)</option>
                                                <option value="AST">(AST) Atlantic Standard Time (Santiago)</option>
                                                <option value="BRT">(BRT) Brasília, São Paulo, Buenos Aires</option>
                                                <option value="FNT">(FNT) South Sandwich Islands</option>
                                                <option value="AZOT">(AZOT) Azores, Cape Verde (Praia)</option>
                                                <option value="WET">(WET) Western European Time (London, Lisbon)
                                                </option>
                                                <option value="CET">(CET) Central European Time (Rome, Paris)</option>
                                                <option value="EET">(EET) Eastern European Time</option>
                                                <option value="AST">(AST) Arabia Standard Time (Baghdad, Riyadh)
                                                </option>
                                                <option value="IRST">(IRST) Iran Standard Time (Tehran)</option>
                                                <option value="MSK">(MSK) Moscow, St. Petersburg, Dubai</option>
                                                <option value="AFT">(AFT) Afghanistan Time (Kabul)</option>
                                                <option value="MVT">(MVT) Karachi, Tashkent, Maldive Islands</option>
                                                <option value="IST">(IST) India Standard Time (Mumbai, Colombo)</option>
                                                <option value="BST">(BST) Yekaterinburg, Almaty, Dhaka</option>
                                                <option value="ICT">(ICT) Bangkok, Hanoi, Jakarta</option>
                                                <option value="CST">(CST) Beijing, Perth, Singapore, Hong Kong</option>
                                                <option value="JST">(JST) Tokyo, Seoul</option>
                                                <option value="ACT">(ACT) ACST (Darwin, Adelaide)</option>
                                                <option value="AEST">(AEST) AEST (Brisbane, Sydney), Yakutsk</option>
                                                <option value="NCT">(NCT) Nouméa, Solomon Islands</option>
                                                <option value="NZST">(NZST) Auckland, Fiji, Marshall Islands</option>
                                                <option value="TKT">(TKT) Fakaofo</option>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button id="btnDone" type="button" class="btn btn-default" data-dismiss="modal">
                                        Done
                                    </button>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div id="confirm_order" class="modal fade" role="dialog">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">×</button>
                                    <h4 class="modal-title">ORDER SUMMER</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="order-summary__body">
                                        <div class="order-summary__body-item" id="source_lang">
                                            <div class="icon order-summary__body-item-icon">
                                                <i class="fas fa-book"></i>
                                            </div>
                                            <span class="order-summary__body-item-label">From</span>
                                            <span class="sourceLangBold">Japanese</span>
                                            <span class="order-summary__body-item-label">to:</span>
                                            <span class="order-summary__body-item-text">1 language</span>
                                        </div>
                                        <div class="order-summary__body-item order-summary__body-item-target-languages" id="target_lang">
                                            <span class="label--outline">English (USA)</span>
                                        </div>
                                        <div class="order-summary__body-item" id="word_count">
                                            <div class="icon order-summary__body-item-icon">
                                                <i class="fas fa-file-word"></i>
                                            </div>
                                            <span class="order-summary__body-item-label">Word count</span>
                                            <span class="order-summary__body-item-text">1000 words</span>
                                        </div>
                                        <div class="order-summary__body-item" id="service_subject">
                                            <div class="icon order-summary__body-item-icon">
                                                <i class="fas fa-suitcase"></i>
                                            </div>
                                            <span class="order-summary__body-item-label">Subject</span>
                                            <span class="order-summary__body-item-text">General</span>
                                        </div>
                                        <div class="order-summary__body-item" id="service_type">
                                            <div class="icon order-summary__body-item-icon">
                                                <i class="fas fa-server"></i>
                                            </div>
                                            <span class="order-summary__body-item-label">Service type</span>
                                            <span class="order-summary__body-item-text">Translation(Mt + light away)</span>
                                        </div>
                                        <div class="order-summary__body-item" id="service_price">
                                            <div class="icon order-summary__body-item-icon">
                                                <i class="fas fa-dollar-sign"></i>
                                            </div>
                                            <span class="order-summary__body-item-label">Price per word</span>
                                            <span class="order-summary__body-item-text">¥17.78 / word</span>
                                        </div>
                                        <div class="order-summary__body-item" id="delivery_time">
                                            <div class="icon order-summary__body-item-icon">
                                                <i class="fas fa-file-word"></i>
                                            </div>
                                            <span class="order-summary__body-item-label">Delivery date</span>
                                            <span class="order-summary__body-item-text">Tue 28 Jul 10:00 PM CST</span>
                                        </div>
                                    </div>
                                    <div class="order-summary__footer" id="total_price">
                                        <h6>Order total <span class="order-summary__total">¥17,779.88</span></h6>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <div class="row" style="margin-right: 0px">
                                        <button class="btn btn-primary order_confirm">Confirm</button>
                                        <button class="btn btn-danger order-cancel">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- LogIn Form Section Ends -->
    <input class="js-dropzone" type="hidden">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>>
    <script src="<?php echo e(asset('assets/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/inputfilter.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/plugins/sweetalert/sweetalert.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {
            let count_error = $('p.error_message');
            count_error.css('display', 'none');


            $("input#word_count").inputFilter(function(value) {
                return /^\d*$/.test(value); });
            $('#order_submit').click(function () {

                let order_data = getValue();

                if (!order_data['word_count']) {
                    count_error.css('display', 'unset');
                    return false
                }
                $.ajax({
                    url: '<?php echo e(route('get_trans_price')); ?>',
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        source_lang: order_data['source_lang'],
                        target_lang: order_data['target_lang'],
                        delivery_type: order_data['delivery_type'],
                        word_count: order_data['word_count'],
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function (response) {
                        let service_mode_type = ['Mt + light away', 'Proofreading'];
                        let delivery_type = $('#order_form input#delivery_type:checked').val();
                        var source_lang = "", lang_length = response.length, target_lang = "", word_count = $('#order_form #word_count').val(), subject = $('#order_form #targetSubject').val(), service_type = "Translation (" + service_mode_type[delivery_type - 1] + ' )', word_price = [], delivery_time = 0, total_price = 0;
                        response.forEach(function (item) {
                            console.log(item);
                            source_lang = item.source_lang;
                            target_lang += '<span class="label--outline">' + item.target_lang + '</span>' + '&nbsp';
                            word_price.push(item.data.price);
                            delivery_time += item.delivery_time;
                            total_price += item.price;

                        });
                        $('#confirm_order div#source_lang span.sourceLangBold').text(source_lang);
                        $('#confirm_order div#source_lang span.order-summary__body-item-text').text(lang_length + " language");
                        $('#confirm_order div.order-summary__body-item-target-languages').html(target_lang);
                        $('#confirm_order div#word_count span.order-summary__body-item-text').text(word_count + " words");
                        $('#confirm_order div#service_subject span.order-summary__body-item-text').text(subject);
                        $('#confirm_order div#service_type span.order-summary__body-item-text').text(service_type);
                        $('#confirm_order div#service_price span.order-summary__body-item-text').text('$ ' + word_price + " / word");
                        $('#confirm_order div#delivery_time span.order-summary__body-item-text').text(delivery_time + ' days');
                        $('#confirm_order div#total_price span.order-summary__total').text('$' + total_price);
                        $('#confirm_order').modal();

                    },
                    error: function (error) {
                        console.log(error);
                    }
                })
            });

            //close the confirm modal
            $('.order-cancel').click(function () {
                $('#confirm_order').modal('toggle');
            });

            //confirm the order
            $('#confirm_order button.order_confirm').click(function () {
                let order_data = getValue();
                let order_data_id = $('#order_form input#order_data_id').val();
                let service_id = $('#order_form input#service_id').val();
                $.ajax({
                    url: '<?php echo e(route('trans_order')); ?>',
                    method: 'POST',
                    dataType: 'json',
                    data: {
                        source_lang: order_data['source_lang'],
                        target_lang: order_data['target_lang'],
                        delivery_type: order_data['delivery_type'],
                        word_count: order_data['word_count'],
                        order_data_id: order_data_id,
                        service_id: service_id,
                        _token: "<?php echo e(csrf_token()); ?>"
                    },
                    success: function (response) {
                        swal({
                                title: response.data,
                                type: "success",
                                confirmButtonColor: "#007BFF",
                                confirmButtonText: "OK",
                            },
                            function(){
                                window.location.href = "<?php echo e(route('project')); ?>";
                            });
                    },
                    error: function (error) {
                        console.log(error);
                    }

                })
            })
        });

        function getValue() {
            let data = [];
            data['source_lang'] = $('#order_form #sourceLanguage').val();
            data['target_lang'] = $('#order_form #targetLanguage').val();
            data['word_count']  = $('#order_form #word_count').val();
            data['subject']  = $('#order_form #targetSubject').val();
            data['delivery_type']  = $('#order_form input#delivery_type:checked').val();

            return data;
        }
    </script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('web.layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Volumes/Work/php/laravel/aivox(laravel)/resources/views/web/pages/user/order.blade.php ENDPATH**/ ?>