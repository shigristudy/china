<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Aivox">
    <meta name="author" content="Illija">
    <title><?php echo e(config('app.name')); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
    <!--Global Styles(used by all pages)-->
    <link href="<?php echo e(asset('backend/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/plugins/metisMenu/metisMenu.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/plugins/fontawesome/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/plugins/typicons/src/typicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('backend/plugins/themify-icons/themify-icons.min.css')); ?>" rel="stylesheet">

    <!--Start Your Custom Style Now-->
    <link href="<?php echo e(asset('backend/dist/css/style.css')); ?>" rel="stylesheet">
    <style>
        .panel {
            box-shadow: 0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22) !important;
        }
    </style>
</head>
<body class="main-background">
<div class="d-flex align-items-center justify-content-center text-center h-100vh">
    <div class="form-wrapper mx-auto">
        <div class="form-container">
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</div>

<!--Global script(used by all pages)-->
<script src="<?php echo e(asset('backend/plugins/jQuery/jquery-3.4.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/dist/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/metisMenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/plugins/perfect-scrollbar/dist/perfect-scrollbar.min.js')); ?>"></script>
</body>
</html><?php /**PATH /var/www/vhosts/aivox.de/httpdocs/resources/views/layouts/auth.blade.php ENDPATH**/ ?>