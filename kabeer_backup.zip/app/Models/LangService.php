<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LangService extends Model
{
    //
    protected $table = 'lang_services';
}
