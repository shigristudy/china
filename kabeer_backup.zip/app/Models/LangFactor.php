<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LangFactor extends Model
{
    //
    protected $table = 'lang_factors';
}
