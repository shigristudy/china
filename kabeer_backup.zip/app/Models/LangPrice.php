<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LangPrice extends Model
{
    //
    protected $table = 'lang_prices';
}
